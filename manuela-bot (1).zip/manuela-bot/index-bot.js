const {default: makeWASocket, makeInMemoryStore, MessageRetryMap, downloadContentFromMessage, DisconnectReason, useMultiFileAuthState, jidDecode } = require ('@adiwajshing/baileys')

//========================//

const pino = require('pino')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const axios = require('axios')
const FileType = require('file-type')
const fetch = require('node-fetch')
const PhoneNumber = require('awesome-phonenumber')
const path = require('path')
const { exec, spawn, execSync } = require("child_process")
const { imageToWebp,  videoToWebp, writeExifImg,  writeExifVid, writeExif } = require('./arquivos/lib/exif')
const { banner, banner2 } = require("./arquivos/lib/functions")
const { color } = require("./arquivos/lib/color")
const { smsg, getBuffer, fetchJson, TelegraPh } = require('./arquivos/lib/simple')
const antifake = JSON.parse(fs.readFileSync('./arquivos/antis/antifake.json'))

// DATA E HORA //
const moment = require("moment-timezone")
const hora = moment.tz("America/Sao_Paulo").format("HH:mm:ss")

//========================//

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })

//========================//

const sessionName = `./QR-MANUELA`

async function startmanu() {
const { state, saveCreds } = await useMultiFileAuthState(`./QR-MANUELA`)

// limpar console
console.log(banner.string)
console.log(banner2.string)
console.log(color('⭐'),color('conectado....🥰'))
const pl= makeWASocket({
logger: pino({ level: 'silent' }),
printQRInTerminal: true,
browser: ['MANUELA-MD-BOT','2A.TREM','8.0'],
auth: state,
msgRetryCounterMap: MessageRetryMap,
defaultQueryTimeoutMs: undefined, 
patchMessageBeforeSending: (message) => {
const requiresPatch = !!(message.buttonsMessage || message.listMessage);
if (requiresPatch) {
message = {viewOnceMessage: {
message: {messageContextInfo: {
deviceListMetadataVersion: 2,
deviceListMetadata: {},
},...message }}}}
return message;
}});

//========================//

require('./DONO/config/data.json')
require('./case')
nocache('./case', module => console.log(` "${hora}" CONFIG ATUALIZADO!`))
nocache('./DONO/config/data.json', module => console.log(` "${hora}" CONFIG ATUALIZADO!`))

store.bind(pl.ev)

//========================//

pl.ev.on('messages.upsert', async chatUpdate => {
try {
//info = chatUpdate.messages[0]
for (let info of chatUpdate.messages) {
if (!info.message) return
m = smsg(pl, info, store)
await pl.readMessages([info.key])
let participant = info.key.participant;
info.message = (Object.keys(info.message)[0] === 'ephemeralMessage') ? info.message.ephemeralMessage.message : info.message
if (!pl.public && !info.key.fromMe && chatUpdate.type === 'notify') return
require("./case")(pl, m, chatUpdate, info, store )
}
} catch (err) {
console.log(err)
}
})

/*
pl.ev.on('messages.upsert', async ({ messages }) => {
try {
info = messages ? messages[0]: messages[1]
await pl.readMessages([info.key])  
if(!info.message) return
if (info.key && info.key.remoteJid == 'status@broadcast') return
let participant = info.key.participant;
info.message = (Object.keys(info.message)[0] === 'ephemeralMessage') ? info.message.ephemeralMessage.message : info.message
if (!pl.public && !info.key.fromMe && chatUpdate.type === 'notify') return
m = smsg(pl, info, store)
require("./case")(pl, m, messages, store)
} catch (err) {
console.log(err)
}
})
*/

//========================//

pl.public = true

pl.serializeM = (m) => smsg(pl, m, store)

pl.ev.on('connection.update', async (update) => {
const {
connection, lastDisconnect, qr, isNewLogin
} = update
if (qr) {
console.log(color("Escanear o qrcode em um ambiente escuro faz com que o foco da câmera seja melhor."))
}


if (isNewLogin?.qr) {
startmanu()
}


if (connection === 'close') {
var shouldReconnect = ((lastDisconnect.error)?.output?.statusCode !== DisconnectReason.loggedOut)
if (String(lastDisconnect.error)
.includes("Stream Errored")) {
console.log(color("Stream errored, o bot pode está conectado em outra sessão. Se essa mensagem continuar repetindo desconecte o bot do Whatsapp.", "yellow"))
} else if (String(lastDisconnect.error)
.includes("Connection Failure")) {
exec(`rm ${sessionName}`)
console.log(color("O bot foi desconectado do WhatsApp, apague e gerar um qr code novo.", "red"))
process.exit()
} else if (String(lastDisconnect.error)
.includes("Restart Required")) {
console.log(color("Reinicie se for nescessario..", "yellow"))
} else if (String(lastDisconnect.error)
.includes("Connection was lost")) {
console.log(color("Conexão perdida", "yellow"))
} else if (String(lastDisconnect.error)
.includes("Connection Terminated")) {
console.log(color("Conexão terminada"))
}

if (lastDisconnect?.error) {
startmanu()
}
}
}) 

pl.ev.on('creds.update', saveCreds);

//===============(BEM VINDO)=============\\

pl.ev.on('group-participants.update', async (manu) => {
  
if(manu.participants[0].startsWith(pl.user.id.split(':')[0])) return 
const grpmdt = await pl.groupMetadata(manu.id)
const isGroup2 = grpmdt.id.endsWith('@g.us') 
const GroupMetadata_ = isGroup2 ? await pl.groupMetadata(manu.id): ""
const mdata_ = isGroup2 ? await pl.groupMetadata(manu.id): ""

// CONST DO CMD DE BANIR QUEM ESTIVER NA LISTA N


const adeuscara = JSON.parse(fs.readFileSync('./arquivos/seguranca/adeuscara.json'))
const dbackid = []
for(i=0;i<adeuscara.length;++i) dbackid.push(adeuscara[i].groupId)
console.log(manu)
if(dbackid.indexOf(manu.id) >= 0) {
if (manu.action == 'add'){ 
num = manu.participants[0]
var ind = dbackid.indexOf(manu.id)
if(adeuscara[ind].actived && adeuscara[ind].number.indexOf(num.split('@')[0]) >= 0) {
await pl.sendMessage(mdata_.id,{text: '*Olha quem deu as cara por aqui, sente o poder do ban cabaço*'})
pl.groupParticipantsUpdate(mdata_.id, [manu.participants[0]], 'remove')
return
}
}
}
// FIM LISTANEGRA CONST ^

// ANTIFAKE QUE ESTÁ JUNTO COM BEM VINDO 

if(antifake.includes(manu.id)) {
if (manu.action === 'add' && !manu.participants[0].startsWith(55)){
num = manu.participants[0]
pl.sendMessage(mdata_.id, {text: 'FAKE AQUI NÃO VAZAAA PORRA ...👋🤬'})
setTimeout(async() => {
pl.groupParticipantsUpdate(mdata_.id, [manu.participants[0]], 'remove')
}, 1000)
}
}


// FIM ANTIFAKE ^

// BEM VINDO COMPLETO 


})

//==============================

pl.ev.on('group-participants.update', async (manu) => {
if(manu.action === 'promote') pl.sendMessage(manu.id, {text: `💦 @${manu.participants[0].split('@')[0]} Foi promovido a adm com sucesso`, mentions: manu.participants})
if(manu.action === 'demote') pl.sendMessage(manu.id, {text: `💦 @${manu.participants[0].split('@')[0]} Foi rebaixado a membro comum com sucesso`, mentions: manu.participants})
})

//========================//

pl.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetch(path)).buffer() : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
}
else {
buffer = await imageToWebp(buff)
}

await pl.sendMessage(jid, {
sticker: {
url: buffer
},
...options
}, {
quoted
})
return buffer
}

//========================//

pl.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await getBuffer(path) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
}
else {
buffer = await videoToWebp(buff)
}

await pl.sendMessage(jid, {
sticker: {
url: buffer
},
...options
}, {
quoted
})
return buffer
}

//========================//

function nocache(module, cb = () => {}) {
fs.watchFile(require.resolve(module), async () => {
await uncache(require.resolve(module))
cb(module)
})
}

//========================//

function uncache(module = '.') {
return new Promise((resolve, reject) => {
try {
delete require.cache[require.resolve(module)]
resolve()
}
catch (e) {
reject(e)
}
})
}

// Setting
pl.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
}
else return jid
}

return pl
}

startmanu()