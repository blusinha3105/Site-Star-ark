const { 'default': AnyWASocket, delay, makeInMemoryStore, downloadContentFromMessage, DisconnectReason, useMultiFileAuthState ,} = require ('@adiwajshing/baileys');

//=====================

const fs = require("fs")
const chalk = require("chalk")
const P = require("pino")
const axios = require('axios')
const clui = require("clui")
const util = require("util")
const ffmpeg = require('fluent-ffmpeg');
const { exec, spawn, execSync } = require("child_process")
const fetch = require("node-fetch")
const yts = require("yt-search")
const Crypto = require("crypto")
const ff = require('fluent-ffmpeg')
const webp = require("node-webpmux")
const path = require("path")
const googleImage = require("g-i-s")
const cheerio = require("cheerio")
const BodyForm = require("form-data")
const mimetype = require("mime-types")
const speed = require("performance-now")
const { color } = require("./arquivos/lib/color")
const { fetchJson } = require("./arquivos/lib/fetcher")
const { fromBuffer } = require("file-type")
const { runtime } = require('./arquivos/lib/myfunc')

const { banner, banner2 } = require("./arquivos/lib/functions")
const { tmpdir } = require("os")
const { Youtube } = require('ytdownloader.js')
const { Mp4Link} = require('./arquivos/lib/scrapers')

//===================== 

// DATA E HORA //
const moment = require("moment-timezone")
const hora = moment.tz("America/Sao_Paulo").format("HH:mm:ss")
const data = moment.tz("America/Sao_Paulo").format("DD/MM/YY")

//=====================
/// ⚜️ARQUIVOS JSON ⚜️ ////

const antiimg = JSON.parse(fs.readFileSync('./arquivos/antis/antiimg.json'))
const antilink = JSON.parse(fs.readFileSync('./arquivos/antis/antilink.json'))
const antilinkhard = JSON.parse(fs.readFileSync('./arquivos/antis/antilinkhard.json'))
const antilinkgp = JSON.parse(fs.readFileSync('./arquivos/antis/antilinkgp.json'))
const antifake = JSON.parse(fs.readFileSync('./arquivos/antis/antifake.json'))
const premium = JSON.parse(fs.readFileSync('./arquivos/usuarios/premium.json'));
const samih = JSON.parse(fs.readFileSync('./arquivos/usuarios/simi.json'));
const samih2 = JSON.parse(fs.readFileSync('./arquivos/antis/simi.json'));
const { insert, response } = require('./arquivos/antis/simi.js');

//=====================

/// ⚜️ARQUIVOS JSON ⚜️ ////
const config = JSON.parse(fs.readFileSync("./DONO/config/data.json"))
const upload = require("./arquivos/lib/functions")
const TelegraPh = require("./arquivos/lib/functions")
const { addFlod , isFlod } = require('./spam.js')
const sotoy = JSON.parse(fs.readFileSync('./arquivos/lib/sotoy.json'));
const { isFiltered, addFilter } = require('./spam.js')
const img = JSON.parse(fs.readFileSync("./arquivos/fotos/logo.json"))
const { palavras } = require('./arquivos/lib/conselhos.js');
const { forwarding, imgnazista, imggay, imgcorno, imggostosa, imggostoso, imgfeio, imgvesgo, imgbebado, imggado, matarcmd, beijocmd, chutecmd, tapacmd } = require("./arquivos/fotos/nescessario.json")
const { menu } = require("./arquivos/menus/menu.js")

const { menufotos } = require("./arquivos/menus/menu.js")
const { menuadm } = require("./arquivos/menus/menu.js")
const { menubrincadeira } = require("./arquivos/menus/menu.js")
const { menualeatorio } = require("./arquivos/menus/menu.js")

const { menufig } = require("./arquivos/menus/menu.js")

//=====================

const { Configuration, OpenAIApi } = require("openai") //precisa baixar o módulo (npm i openai)
const configopen = new Configuration({apiKey: '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'}); //coloca sua key aqui
const openai = new OpenAIApi(configopen); //configuração do openai (sincronização da sua key)
tohkapi = 'Lh5cckAMqg'

//=====================

///  prefixo e dono aqui ///
 logo = img.logo
 nomeBot = config.nomeBot
 numeroBot = config.numeroBot
 nomeDono = config.nomeDono
 numeroDono = config.numeroDono
 dono = config.numeroDono
 prefix = config.prefix
 prefixo = config.prefix
 packname = config.packname
 author = config.author

consoleoff = config.consoleoff
botoes = config.botoes
menu_audio = config.menu_audio
//=====================

let girastamp = speed()
let latensi = speed() - girastamp

//=====================

module.exports = pl = async (pl, m, msg, info, store, messages ) => {
try {
const type = Object.keys(info.message)[0] == 'senderKeyDistributionMessage' ? Object.keys(info.message)[2] : (Object.keys(info.message)[0] == 'messageContextInfo') ? Object.keys(info.message)[1] : Object.keys(info.message)[0]
const content = JSON.stringify(info.message);
const altpdf = Object.keys(info.message)
global.prefix
const from = info.key.remoteJid
var body = (type === 'conversation') ? info.message.conversation : (type == 'imageMessage') ? info.message.imageMessage.caption : (type == 'videoMessage') ? info.message.videoMessage.caption : (type == 'extendedTextMessage') ? info.message.extendedTextMessage.text : (type == 'buttonsResponseMessage') ? info.message.buttonsResponseMessage.selectedButtonId : (type == 'listResponseMessage') ? info.message.listResponseMessage.singleSelectReply.selectedRowId : (type == 'templateButtonReplyMessage') ? info.message.templateButtonReplyMessage.selectedId : ''
const budy = (type === 'conversation') ? info.message.conversation : (type === 'extendedTextMessage') ? info.message.extendedTextMessage.text : ''
var pes = (type === 'conversation' && info.message.conversation) ? info.message.conversation : (type == 'imageMessage') && info.message.imageMessage.caption ? info.message.imageMessage.caption : (type == 'videoMessage') && info.message.videoMessage.caption ? info.message.videoMessage.caption : (type == 'extendedTextMessage') && info.message.extendedTextMessage.text ? info.message.extendedTextMessage.text : ''
const args = body.trim().split(/ +/).slice(1)
const isCmd = body.startsWith(prefixo)
const command = isCmd ? body.slice(1).trim().split(/ +/).shift().toLocaleLowerCase() : null

//================(BADY)================\\
 
bady = (type === 'conversation') ? info.message.conversation : (type == 'imageMessage') ? info.message.imageMessage.caption : (type == 'videoMessage') ? info.message.videoMessage.caption : (type == 'extendedTextMessage') ? info.message.extendedTextMessage.text : (info.message.listResponseMessage && info.message.listResponseMessage.singleSelectReply.selectedRowId) ? info.message.listResponseMessage.singleSelectReply.selectedRowId: ''

bidy =bady.toLowerCase()

//===============(BUDY)==================\\

var budy2 = body.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");


   
//*******************************************//
const getRandom = (ext) => {
	return `${Math.floor(Math.random() * 10000)}${ext}`
}
const getExtension = async (type) => {
return await mimetype.extension(type)
 }
const getBuffer = (url, options) => new Promise(async (resolve, reject) => { 
options ? options : {}
await axios({method: "get", url, headers: {"DNT": 1, "Upgrade-Insecure-Request": 1}, ...options, responseType: "arraybuffer"}).then((res) => {
resolve(res.data)
}).catch(reject)
})
//***************[ FUNÇÕES ]***************//

///////////////
const getFileBuffer = async (mediakey, MediaType) => { 
const stream = await downloadContentFromMessage(mediakey, MediaType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}
const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ? pl.sendMessage(from, {text: teks.trim(), mentions: memberr}) : pl.sendMessage(from, {text: teks.trim(), mentions: memberr})
}
const getGroupAdmins = (participants) => {
admins = []
for (let i of participants) {
if(i.admin == "admin") admins.push(i.id)
if(i.admin == "superadmin") admins.push(i.id)
}
return admins
}
const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()
const arg = body.substring(body.indexOf(" ") + 1)
const numeroBot = pl.user.id.split(":")[0]+"@s.whatsapp.net"
const argss = body.split(/ +/g)
const botNumber = pl.user.id.split(':')[0]+'@s.whatsapp.net'
const itsMe = m.sender == botNumber ? true : false
const testat = body
const ants = body
const isGroup = info.key.remoteJid.endsWith("@g.us")
const tescuk = ["0@s.whatsapp.net"]
const q = args.join(" ")
const isUrl = (url) => {
	return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
const sender = isGroup ? info.key.participant : info.key.remoteJid
const pushname = info.pushName ? info.pushName : ""
const groupMetadata = isGroup ? await pl.groupMetadata(from) : ""
const groupName = isGroup ? groupMetadata.subject : ""
const groupDesc = isGroup ? groupMetadata.desc : ""
const groupMembers = isGroup ? groupMetadata.participants : ""
const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ""
const canal = config.canal
const grupo = config.grupo
const text = args.join(" ")
const c = args.join(' ')
const reply = (texto) => {
pl.sendMessage(from, { text: texto }, {quoted: info})
} 

// VERIFICADOS ⭐️
const live = {key : {participant : '0@s.whatsapp.net'},message: {liveLocationMessage: {}}} 
const imgm = {key : {participant : '0@s.whatsapp.net'},message: {imageMessage: {}}}
const vid = {key : {participant : '0@s.whatsapp.net'},message: {videoMessage: {}}}
const contato = {key : {participant : '0@s.whatsapp.net'},message: {contactMessage:{displayName: `${pushname}`}}}
const doc = {key : {participant : '0@s.whatsapp.net'},message: {documentMessage:{}}}



//configruracao de dono, adm etc...
const quoted = info.quoted ? info.quoted : info
const mime = (quoted.info || quoted).mimetype || ""
const isBot = info.key.fromMe ? true : false
const isBotGroupAdmins = groupAdmins.includes(numeroBot) || false
const isGroupAdmins = groupAdmins.includes(sender) || false 
const SoDono = sender.includes(numeroDono)
//const SoDono = numeroDono.includes(numeroDono)
const groupId = isGroup ? groupMetadata.jid : ''
banChats = true
const argis = bidy.trim().split(/ +/)

//============(simi)============\\

const isSimi = isGroup ? samih.includes(from) : false
const isSimi2 = isGroup ? samih2.includes(from) : false

const isAntiImg = isGroup ? antiimg.includes(from) : false
const isAntiLinkHard = isGroup ? antilinkhard.includes(from) : false
const isAntilinkgp = isGroup ? antilinkgp.includes(from) : false
const isAntifake = isGroup ? antifake.includes(from) : false
const isPremium = premium.includes(sender)

// Consts isQuoted
const isImage = type == "imageMessage"
const isVideo = type == "videoMessage"
const isAudio = type == "audioMessage"
const isSticker = type == "stickerMessage"
const isContact = type == "contactMessage"
const isLocation = type == "locationMessage"
const isProduct = type == "productMessage"
const isMedia = (type === "imageMessage" || type === "videoMessage" || type === "audioMessage")
typeMessage = body.substr(0, 50).replace(/\n/g, "")
if (isImage) typeMessage = "Image"
else if (isVideo) typeMessage = "Video"
else if (isAudio) typeMessage = "Audio"
else if (isSticker) typeMessage = "Sticker"
else if (isContact) typeMessage = "Contact"
else if (isLocation) typeMessage = "Location"
else if (isProduct) typeMessage = "Product"
const isQuotedMsg = type === "extendedTextMessage" && content.includes("textMessage")
const isQuotedImage = type === "extendedTextMessage" && content.includes("imageMessage")
const isQuotedVideo = type === "extendedTextMessage" && content.includes("videoMessage")
const isQuotedDocument = type === "extendedTextMessage" && content.includes("documentMessage")
const isQuotedAudio = type === "extendedTextMessage" && content.includes("audioMessage")
const isQuotedSticker = type === "extendedTextMessage" && content.includes("stickerMessage")
const isQuotedContact = type === "extendedTextMessage" && content.includes("contactMessage")
const isQuotedLocation = type === "extendedTextMessage" && content.includes("locationMessage")
const isQuotedProduct = type === "extendedTextMessage" && content.includes("productMessage")

outrasVariavel = "bot"

let {name, urlMinhaApikey, aurlSexo, compreSuaApikey, cdd, crtt, baterai, charging, autoHourActivate, emoji_bot, blocked, multi, nopref, variosPrefixo, leitor} = outrasVariavel

//=========================

function DLT_FL(file) { try { fs.unlinkSync(file); } catch (error) { return; } }

if(budy == `${prefixo}`) {
reply('🤔👍')}

//=============DATA=============
const date = moment.tz('America/Sao_Paulo').format('DD/MM/YY');
const time = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
const hora = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
const dataa = moment.tz('America/Sao_Paulo').format('DD/MM/YY');

////////////////////////////////////
// ❗𝙲𝙾𝙼𝙰𝙽𝙳𝙾 𝙽𝙾 𝙿𝚅❗
if (!isGroup && isCmd) console.log(
color(' ❗𝙲𝙾𝙼𝙰𝙽𝙳𝙾 𝙽𝙾 𝙿𝚅❗','white'),'\n',
color('‣ ΝᏆᏟᏦ :','red'),color(pushname,'cyan'),'\n',
color('‣ ΝႮ́ᎷᎬᎡϴ :','red'),color(sender.split("@")[0],'blue'),'\n',
color('‣ ᏟᎷᎠ :','red'),color(command,'cyan'),'\n',
color('‣ ᎻϴᎡᎪ :','red'),color(hora,'cyan'),'\n')

// ❗𝙼𝙴𝙽𝚂𝙰𝙶𝙴𝙼 𝙽𝙾 𝙿𝚅❗
if (!isCmd && !isGroup && !info.key.fromMe) console.log(
color('❗𝙼𝙴𝙽𝚂𝙰𝙶𝙴𝙼 𝙽𝙾 𝙿𝚅❗','white'),'\n',
color('‣ ΝႮ́ᎷᎬᎡϴ :','red'),color(sender.split("@")[0],'blue'),'\n',
color('‣ ΝᏆᏟᏦ :','red'),color(pushname,'cyan'),'\n',
color('‣ ᎻϴᎡᎪ :','red'),color(hora,'cyan'),'\n')

// ❗𝙲𝙾𝙼𝙰𝙽𝙳𝙾 𝙴𝙼 𝙶𝚁𝚄𝙿𝙾❗
if (isCmd && isGroup) console.log(
color('❗𝙲𝙾𝙼𝙰𝙽𝙳𝙾 𝙴𝙼 𝙶𝚁𝚄𝙿𝙾❗','white'),'\n',
color('‣ ᏀᎡႮᏢϴ :','blue'),color(groupName,'yellow'),'\n',
color('‣ ΝႮ́ᎷᎬᎡϴ :','blue'),color(sender.split("@")[0],'red'),'\n',
color('‣ ΝᏆᏟᏦ :','blue'),color(pushname,'yellow'),'\n',
color('‣ ᏟᎷᎠ :','blue'),color(command,'yellow'),'\n',
color('‣ ᎻϴᎡᎪ :','blue'),color(hora,'yellow'),'\n')

// ❗𝙼𝙴𝙽𝚂𝙰𝙶𝙴𝙼 𝙴𝙼 𝙶𝚁𝚄𝙿𝙾❗
if (!isCmd && isGroup && !info.key.fromMe) console.log(
color('❗𝙼𝙴𝙽𝚂𝙰𝙶𝙴𝙼 𝙴𝙼 𝙶𝚁𝚄𝙿𝙾❗','white'),'\n',
color('‣ ᏀᎡႮᏢϴ :','blue'),color(groupName,'cyan'),'\n',
color('‣ ΝႮ́ᎷᎬᎡϴ :','blue'),color(sender.split("@")[0],'red'),'\n',
color('‣ ΝᏆᏟᏦ :','blue'),color(pushname,'cyan'),'\n',
color('‣ ᎻϴᎡᎪ :','blue'),color(hora,'cyan'),'\n')

//===================================== 
if (/document/i.test(type)) console.log(`🗂️ ${m.msg.fileName || m.msg.displayName || 'Document'}`)
else if (/ContactsArray/i.test(type)) console.log(`👨‍👩‍👧‍👦 ${' ' || ''}`)
else if (/contact/i.test(type)) console.log(`👨 ${m.msg.displayName || ''}`)
else if (/audio/i.test(type)) {
const duration = m.msg.seconds
console.log(`${m.msg.ptt ? '🎤 ᎷᎬΝՏᎪᏀᎬᎷ ᎠᎬ ᏙϴᏃ' : '🎵 Ꭺ́ႮᎠᏆϴ'} ${Math.floor(duration / 60).toString().padStart(2, 0)}:${(duration % 60).toString().padStart(2, 0)}`)
}


// FUNCAO DE ANTILINK \\
//=================================\\

let isTrueFalse = Array('tiktok','facebook','instagram','twitter','ytmp3','ytmp4','play').some(item => item === command)
async function AntilinkHardF() {
if(isUrl(budy2) && isAntiLinkHard && isGroupAdmins && isBotGroupAdmins && !info.key.fromMe) {
if(command == "tiktok" && command == "facebook" && command == "instagram" && command == "tiktok" && command == "twitter" && command == "ytmp3" && command == "ytmp4" && command == "play") return
linkgpp = await pl.groupInviteCode(from)
if(budy2.match(`${linkgpp}`)) return
if(!isUrl(budy2)) return 
if(type === "buttonsResponseMessage") return
if(type === "listResponseMessage") return
if(budy2.includes(`${linkgpp}`)) return 
reply('*Link detectado, porém usuário é admin*')
if(menu_audio === true) {
  setTimeout(() => {reagir(from, "👑")}, 300)
audiomenu = await fs.readFileSync("./arquivos/audios/ban1.mp3")
pl.sendMessage(from, {audio: audiomenu, mimetype: 'audio/mp4', ptt:true}, {quoted: info})
reply(`🗑️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n🗑️\n❲❗❳ *Lɪᴍᴘᴇᴢᴀ ᴅᴇ Cʜᴀᴛ Cᴏɴᴄʟᴜɪ́ᴅᴀ* ✅`)
}  
}

if(isUrl(budy2) && isAntiLinkHard && !isGroupAdmins && isBotGroupAdmins && !info.key.fromMe) {
if(command == "tiktok" && command == "facebook" && command == "instagram" && command == "tiktok" && command == "twitter" && command == "ytmp3" && command == "ytmp4" && command == "play") return  
linkgpp = await pl.groupInviteCode(from)
if(budy2.match(`${linkgpp}`)) return reply('Link do nosso grupo, não irei remover.. ')  
if(!isUrl(budy2)) return 
if(type === "buttonsResponseMessage") return
if(type === "listResponseMessage") return
setTimeout(() => {
pl.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender}})
}, 500)
reply('*Link detectado, punindo usuário...*')
if(!JSON.stringify(groupMembers).includes(sender)) return
pl.groupParticipantsUpdate(from, [sender], 'remove')
if(menu_audio === true) {
  setTimeout(() => {reagir(from, "👑")}, 300)
audiomenu = await fs.readFileSync("./arquivos/audios/ban1.mp3")
pl.sendMessage(from, {audio: audiomenu, mimetype: 'audio/mp4', ptt:true}, {quoted: info})
reply(`🗑️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n🗑️\n❲❗❳ *Lɪᴍᴘᴇᴢᴀ ᴅᴇ Cʜᴀᴛ Cᴏɴᴄʟᴜɪ́ᴅᴀ* ✅`)
}  
}
}
AntilinkHardF()

if(isUrl(body) && isAntilinkgp && isGroup && isBotGroupAdmins) {
if(!isAntilinkgp) return
if(!isUrl(body)) return 
if(budy2.includes("chat.whatsapp.com/")){
if(!budy2.includes("chat.whatsapp.com/")) return
if(isBot) return 
linkgpp = await pl.groupInviteCode(from)
if(budy.match(`${linkgpp}`)) return reply('Link do nosso grupo, não irei remover.. ')  
if(isGroupAdmins) return reply("Você é adm, não removerei você..")
setTimeout(() => {
pl.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender}})
}, 500)
if(!JSON.stringify(groupMembers).includes(sender)) return
pl.groupParticipantsUpdate(from, [sender], 'remove')
if(menu_audio === true) {
  setTimeout(() => {reagir(from, "👑")}, 300)
audiomenu = await fs.readFileSync("./arquivos/audios/ban1.mp3")
pl.sendMessage(from, {audio: audiomenu, mimetype: 'audio/mp4', ptt:true}, {quoted: info})
reply(`🗑️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n🗑️\n❲❗❳ *Lɪᴍᴘᴇᴢᴀ ᴅᴇ Cʜᴀᴛ Cᴏɴᴄʟᴜɪ́ᴅᴀ* ✅`)
}  
}
}

if(isGroup && isBotGroupAdmins && !isGroupAdmins && !SoDono && !info.key.fromMe) {
if(info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length == groupMembers.length || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length == groupMembers.length - 1) { 
reply("Membro comum com mensagem de marcação de todos do grupo, por conta disso irei remover do grupo, qualquer coisa entre em contato com um administrador...")
pl.groupParticipantsUpdate(from, [sender], "remove")
}
}

//======(ANTI-IMAGEM)========\\
if(isAntiImg && isBotGroupAdmins && type == 'imageMessage') {
if (info.key.fromMe) return
if(isGroupAdmins) return pl.sendMessage(from, {text:'*mensagem proibida detectada, porém é admin logo a punição será anulada*'}, {quoted: info})
setTimeout(() => {
pl.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender}})
}, 500)
setTimeout(async function () {
if(!JSON.stringify(groupMembers).includes(sender)) return  
pl.groupParticipantsUpdate(from, [sender], 'remove')
}, 1000)
}

//=====================

if(botoes == false) {
var sendBimg = async (id, img1, text1) => {
pl.sendMessage(id, {image: {url: img1}, caption: text1}, {quoted: info})
}
} else {
// resposta BOTÃO COM IMAGEM
var sendBimg = async (id, img1, text1, desc1, but = [], vr) => {
buttonMessage = {
image: {url: img1},
caption: text1,
footerText: desc1,
buttons: but,
headerType: 4
}
pl.sendMessage(id, buttonMessage, {quoted: vr})
}
}

//=====================

if(botoes == false) {
var sendBtext = async (id, text1) => {
pl.sendMessage(id, {text: text1}, {quoted: info})
}
} else {
// resposta BOTÃO COM TEXTO
var sendBtext = async (id, text1, desc1, but = [], vr) => {
buttonMessage = {
text: text1,
footer: desc1,
buttons: but,
headerType: 1
}
pl.sendMessage(id, buttonMessage, {quoted: vr})
}
}
//=====================
//=======================================\\
// aqui e o simih, sever pra interagir nos grupo
//não mexa pra não dar erro

const simih = async (text) => {
try {
const sami = await fetch(`https://api.brizaloka-api.tk/ia/simsimi?apikey=brizaloka&text=${text}`, {method: 'GET'})
const res = await sami.json()
return res.resultado.resposta
} catch {
return 'Simi não sabe, pfvr explique ??'
}
}

//=======================================\\

const mencionar = ( foto, texto, membro, ids ) => {
( ids == null || ids == undefined || ids == false ) ? pl.sendMessage(from, { image: foto, caption: texto.trim(), contextInfo: { "mentionedJid": membro } }) : pl.sendMessage(from, { image: foto, caption: texto.trim(), contextInfo: { "mentionedJid": membro } })
}

//-_-_-_-_--_-_-_-_-_--_-JSON-FUNÇÕES-_-_-_-_-_-_-_-_-_-_-_-_\\

const { addVotoDuelo, delVotoDuelo } = require('./arquivos/dados/votoduelo.js')
const votacao = JSON.parse(fs.readFileSync('./arquivos/dados/votacao/votacao.json'))
const votacaoduelo = JSON.parse(fs.readFileSync('./arquivos/dados/duelo/votacaoduelo.json'))

//-_-_-_-_--_-_-_-_-_--_--_-_-_-_-_-_-_-_-_-_-_-_\\

//============(FUNÇÕES)============\\

const isVoto = isGroup ? votacao.includes(from) : false
const isVotoDuelo = isGroup ? votacaoduelo.includes(from) : false

//-_-_-_-_--_-_-_-_-_--_--_-_-_-_-_-_-_-_-_-_-_-_\\

/** VOTAÇÃO ESTILO DUELO : VS **/

if( isGroup ) {
if (budy.toLowerCase() === 'um'){
let voto = JSON.parse(fs.readFileSync(`./arquivos/dados/duelo/P_votos/${from}.json`))
let _votos = JSON.parse(fs.readFileSync(`./arquivos/dados/duelo/votos/${from}.json`))
let filtro = voto.map(v => v.participante)
let id_voto = sender ? sender : '0@s.whatsapp.net'
if(filtro.includes(id_voto)) {
return mentions('Olá '+'@' + sender.split('@')[0] + '\n~ Não é possível votar duas vezes.', filtro, true)
} else {
voto.push({
participante: id_voto,
votacao: '1'
})
fs.writeFileSync(`./arquivos/dados/duelo/P_votos/${from}.json`,JSON.stringify(voto))
let _p = []
let _voto = `VOTAÇÃO...\n\nParticipante 1: @${_votos[0].votos.split('@')[0]}\nParticipante 2: @${_votos[0].votos2.split('@')[0]}\nMotivo da votação: ${_votos[0].razao}\nTotal de votos: ${voto.length}.\nDuração: ${_votos[0].duracao} minuto.`
for(let i = 0; i < voto.length; i++) {
_voto +=`\n\n========\nMembro: @${voto[i].participante.split('@')[0]}\nVotou em: ${voto[i].votacao}\n========`
_p.push(voto[i].participante)
}
_p.push(_votos[0].votos, _votos[0].votos2)
mentions(_voto,_p,true)
}
} else if (budy.toLowerCase() === 'dois'){
const voto = JSON.parse(fs.readFileSync(`./arquivos/dados/duelo/P_votos/${from}.json`))
let _votos = JSON.parse(fs.readFileSync(`./arquivos/dados/duelo/votos/${from}.json`))
let filtro = voto.map(v => v.participante)
let id_voto = sender ? sender : '0@s.whatsapp.net'
if(filtro.includes(id_voto)) {
return mentions('Olá '+'@' + sender.split('@')[0] + '\n~ Não é possivel votar duas vezes.', filtro, true)
} else {
voto.push({
participante: id_voto,
votacao: '2'
})
fs.writeFileSync(`./arquivos/dados/duelo/P_votos/${from}.json`,JSON.stringify(voto))
let _p = []
let _voto = `VOTAÇÃO...\n\nParticipante 1: @${_votos[0].votos.split('@')[0]}\nParticipante 2: @${_votos[0].votos2.split('@')[0]}\nMotivo da votação: ${_votos[0].razao}\nTotal de votos: ${voto.length}.\nDuração: ${_votos[0].duracao} minuto.`
for(let i = 0; i < voto.length; i++) {
_voto +=`\n\n========\nMembro: @${voto[i].participante.split('@')[0]}\nVotou em: ${voto[i].votacao}\n========\n`
_p.push(voto[i].participante)
}
_p.push(_votos[0].votos, _votos[0].votos2)
mentions(_voto,_p,true)
}
}
}



// RESPOSTAS DOS COMANDOS \\
resposta = {
espere: "💦 Aguarde...enviando ",
aguarde: "💦 Aguarde...enviando ",
dono: "💦 Esse comando so pode ser usado pelo meu dono!!! ",
grupo: "💦 Esse comando só pode ser usado em grupo ",
privado: "💦 Esse comando só pode ser usado no privado ",
adm: "💦 Esse comando só pode ser usado por administradores de grupo",
botadm: " 💦 Este comando só pode ser usado quando o bot se torna administrador ",
registro: `[⚙️️] Você não se registrou utilize ${prefixo}rg para se registrar `,
norg: "[⚙️️] Você ja está registrado ",
erro: "💦 Error, tente novamente mais tarde "
}



switch (command) {
// Começo dos comandos com prefix //
//     /\/\
//    (° v °)
//    /|    |\    
//     V---V
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^//

case "help":
case "comandos":
case 'menu':
case "start":
case "bot":
templateMassage = {
image: {url:"./arquivos/fotos/manu.jpg",
quoted: info},
caption: menu(prefixo, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender),
footer: nomeBot,
headerType: 4,
contextinfo:{externalAdReply:{
title: nomeBot,
body: "𝑩𝒚 manuela",
footer:  nomeDono,
thumbnail: global.goimg,
mediaType:2,
//templateButtons: templateButtons
}}
}
pl.sendMessage(from, templateMassage)
break

/*
case "help":
case "comandos":
case 'menu':
case "start":
case "bot":
reply(resposta.aguarde)

const sections = [
{
	title: `${nomeBot}`,
	rows: [
	{title: "MENU ADM", rowId: `${prefix}menuadm`, description: `${nomeBot}`},
	{title: "MENU BÔNUS", rowId: `${prefix}menualeatorio`, description: `${nomeBot}`},
	{title: "MENU BRINCADEIRA", rowId: `${prefix}menubrincadeira`, description: `${nomeBot}`},
	{title: "MENU FOTOS", rowId: `${prefix}menufotos`, description: `${nomeBot}`}
	]
}
]
const listMessage = {
  text: menu(prefixo, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender),
  buttonText: "Ver menus...",
  sections
}
pl.sendMessage(from, listMessage)
break
*/

case "menufig":
templateMassage = {
image: {url:"./arquivos/fotos/manu.jpg",
quoted: info},
caption: menufig(prefixo, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender),
footer: nomeBot,
headerType: 4,
contextinfo:{externalAdReply:{
title: nomeBot,
body: "𝑩𝒚 manuela",
footer:  nomeDono,
thumbnail: global.goimg,
mediaType:2,
//templateButtons: templateButtons
}}
}
pl.sendMessage(from, templateMassage)
break

case "menuadm":
templateMassage = {
image: {url:"./arquivos/fotos/manu.jpg",
quoted: info},
caption: menuadm(prefixo, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender),
footer: nomeBot,
headerType: 4,
contextinfo:{externalAdReply:{
title: nomeBot,
body: "𝑩𝒚 manuela",
footer:  nomeDono,
thumbnail: global.goimg,
mediaType:2,
//templateButtons: templateButtons
}}
}
pl.sendMessage(from, templateMassage)
break

case "menubrincadeira":
templateMassage = {
image: {url:"./arquivos/fotos/manu.jpg",
quoted: info},
caption: menubrincadeira(prefixo, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender),
footer:  nomeBot,
headerType: 4,
contextinfo:{externalAdReply:{
title: nomeBot,
body: "𝑩𝒚 PLZINHO",
footer: nomeDono,
thumbnail: global.goimg,
mediaType:2,
//templateButtons: templateButtons
}}
}
pl.sendMessage(from, templateMassage)
break

case "menualeatorio":
templateMassage = {
image: {url:"./arquivos/fotos/manu.jpg",
quoted: info},
caption: menualeatorio(prefixo, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender),
footer:  nomeBot,
headerType: 4,
contextinfo:{externalAdReply:{
title: nomeBot,
body: "𝑩𝒚 PLZINHO",
footer: nomeDono,
thumbnail: global.goimg,
mediaType:2,
//templateButtons: templateButtons
}}
}
pl.sendMessage(from, templateMassage)
break

case "menufotos":
templateMassage = {
image: {url:"./arquivos/fotos/manu.jpg",
quoted: info},
caption: menufotos(prefixo, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender),
footer:  nomeBot,
headerType: 4,
contextinfo:{externalAdReply:{
title: nomeBot,
body: "𝑩𝒚 PLZINHO",
footer: nomeDono,
thumbnail: global.goimg,
mediaType:2,
//templateButtons: templateButtons
}}
}
pl.sendMessage(from, templateMassage)
break


case 'cassino':
addFilter(from)  
const soto = [
'🍊 : 🍒 : 🍐',
'🍒 : 🔔 : 🍊',
'🍇 : 🍇 : 🍇',
'🍊 : 🍋 : 🔔',
'🔔 : 🍒 : 🍐',
'🔔 : 🍒 : 🍊',
'🍊 : 🍋 : ??',		
'🍐 : 🍒 : 🍋',
'🍐 : 🍐 : 🍐',
'🍊 : 🍒 : 🍒',
'🔔 : 🔔 : 🍇',
'🍌 : 🍒 : 🔔',
'🍐 : 🔔 : 🔔',
'🍊 : 🍋 : 🍒',
'🍋 : 🍋 : 🍌',
'🔔 : 🔔 : 🍇',
'🔔 : 🍐 : 🍇',
'🔔 : 🔔 : 🔔',
'🍒 : 🍒 : 🍒',
'🍌 : 🍌 : 🍌'
]		  

if(botoes === false) {
reply(`Se essa mensagem está sendo enviada, provavelmente os botões estão desligado`)
} else {

const somtoy2 = sotoy[Math.floor(Math.random() * sotoy.length)]
if ((somtoy2 == '🥑 : 🥑 : 🥑') ||(somtoy2 == '🍉 : 🍉 : 🍉') ||(somtoy2 == '🍓 : 🍓 : 🍓') ||(somtoy2 == '🍎 : 🍎 : 🍎') ||(somtoy2 == '🍍 : 🍍 : 🍍') ||(somtoy2 == '🥝 : 🥝 : 🥝') ||(somtoy2 == '🍑 : 🍑 : 🍑') ||(somtoy2 == '🥥 : 🥥 : 🥥') ||(somtoy2 == '🍋 : 🍋 : 🍋') ||(somtoy2 == '🍐 : 🍐 : 🍐') ||(somtoy2 == '🍌 : 🍌 : 🍌') ||(somtoy2 == '🍒 : 🍒 : 🍒') ||(somtoy2 == '🔔 : 🔔 : 🔔') ||(somtoy2 == '🍊 : 🍊 : 🍊') ||(somtoy2 == '🍇 : 🍇 : 🍇')) {
var Vitória = "Você ganhou!!!"
} else {
var Vitória = "Você perdeu..."
}

const cassino = `
┏━━━━❪🎰❫━━━━
┣► ${somtoy2}◄┛
┗━━━━❪💰❫━━━━

*${Vitória}*`
  
sendBtext(from, `${cassino}`, `${Vitória}`, [
{buttonId: `${prefix}cassino`, buttonText: {displayText: `Proximo`}, type: 1}], info)
}
break


/*
case "ping":
reply(`💦 Velocidade de resposta ${latensi.toFixed(4)} segundos `)
break
*/

case "tmgp": 
case "tmgrupo": {
if (!SoDono) return reply(resposta.dono)
if (!args.join(" ")) return reply(`kd o texto amiguinho?`)
const tm = args.join(' ')
let getGroups = await pl.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
reply(`﹤♧﹥ *𝙀𝙣𝙫𝙞𝙖𝙣𝙙𝙤 𝙖 ${anu.length} 𝙜𝙧𝙪𝙥𝙤𝙨`)
waifuzdd = await axios.get('https://waifu.pics/api/sfw/neko')
for (let i of anu) {
await delay(1500)
templateButtons = [
{index: 1, urlButton: {displayText: 'Criador', url: canal}},
{index: 2, urlButton: {displayText: 'Dono', url: grupo}},
]
templateMessago = {
image: {url:waifuzdd.data.url,
quoted: info},
caption: tm,
footer: 'transmissão',
//templateButtons: templateButtons
}
pl.sendMessage(i, templateMessago)
}
reply("✔️pronto...")
}
break


case "ppt": 
if (!isGroup) return reply(resposta.grupo)
if (args.length < 1) return reply('exemplo: /ppt pedra')
ppt = ["pedra","papel","tesoura"]
ppy = ppt[Math.floor(Math.random() * ppt.length)]
ppg = Math.floor(Math.random() * 50)
pptb = ppy
pph = `Você ganhou ${ppg} em money`
if ((pptb == "pedra" && args == "papel") || 
(pptb == "papel" && args == "tesoura") || 
(pptb == "tesoura" && args == "pedra")) {
var vit = "vitoria"
} else if ((pptb == "pedra" && args == "tesoura") || 
(pptb == "papel" && args == "pedra") || 
(pptb == "tesoura" && args == "papel")) {
var vit = "derrota"
} else if ((pptb == "pedra" && args == "pedra") ||
(pptb == "papel" && args == "papel") ||
(pptb == "tesoura" && args == "tesoura")) {
var vit = "empate"
} else if (vit = "undefined") {
return reply(linguagem.tterro())
}
if (vit == "vitoria") {
var tes = "Vitória do jogador"
}
if (vit == "derrota" ) {
var tes = "A vitória é do bot"
}
if (vit == "empate" ) {
var tes = "O jogo terminou em empate"
}
reply(`Bot jogou: ${pptb}\nO jogador jogou: ${args}\n\n${tes}`)
if (tes == "Vitória do jogador") {
reply(pph)
}
break

case 'clear': case "reiniciar":
if (!SoDono) return reply(resposta.dono)
reply(' L I M P A N D U 😎🤙\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nlimpo')
break

case 'prefixo-bot': case 'setprefix':
if (args.length < 1) return
if (!SoDono && !info.key.fromMe) return reply(resposta.dono)
prefix = args[0]
config.prefix = prefix
fs.writeFileSync('./DONO/config/data.json', JSON.stringify(config, null, '\t'))
reply(`O prefixo foi alterado com sucesso para: ${config.prefix}`)
break

case 'perfil':
try {
ppimg = await pl.profilePictureUrl(`${sender.split("@")[0]}@c.us`, "image")
} catch(e) {
ppimg = logo
}
perfil = await getBuffer(ppimg)

var conselho = palavras[Math.floor(Math.random() * palavras.length)]
const nivelgado = ['1','2','3','4','5','6','7','8','9']
const nivelgado2 = ['1','2','3','4','5','6','7','8','9'] 
const nivelgador = nivelgado[Math.floor(Math.random() * (nivelgado.length))]
const nivelgado2r = nivelgado2[Math.floor(Math.random() * (nivelgado2.length))] 
const puta = ['1','2','3','4','5','6','7','8','9']
const puta2 = ['1','2','3','4','5','6','7','8','9'] 
const putar = puta[Math.floor(Math.random() * (puta.length))]
const putar2 = puta2[Math.floor(Math.random() * (puta2.length))] 
const gostosura = ['1','2','3','4','5','6','7','8','9']
const gostosura2 = ['1','2','3','4','5','6','7','8','9'] 
const gostosurar = gostosura[Math.floor(Math.random() * (gostosura.length))]
const gostosurar2 = gostosura2[Math.floor(Math.random() * (gostosura2.length))] 
var bio = await pl.fetchStatus(sender)
var bioo = bio.status
gadop = `${Math.floor(Math.random() * 100)}`
const programa = Math.ceil(Math.random() * 10000)
const dptr = `
        • ❪ SEU PERFIL ❫ •
┏⊱
╿•🗒 *Nome* : *${pushname}*
╿
╿•🥰 ${!isGroup ? `𝗨𝘀𝘂𝗮𝗿𝗶𝗼: ${pushname}` :`𝗚𝗿𝘂𝗽𝗼: ${groupName}`}
╿•🪀 *Número* : wa.me/${sender.split("@")[0]}
╿•🗯 *SUA BIO* : ${bioo ? `${bioo}` :`privado`}
╿•🐂 *Nível gado* : *${nivelgador}${nivelgado2r}%*
╿•📱 *Seu Celular* : ${m.key.id.length > 21 ? 'Android 🤣' : m.key.id.substring(0, 2) == '3A' ? 'IOS😂😂😅' : 'Zap zap web 😂😂☝🏼😅'}
╿•😈 *Nível puta* : *${putar}${putar2}%*
╿•😋 *Nível de gostosura* : *${gostosurar}${gostosurar2}%*
╿•🍼 *Valor do programa* : *R$${programa}*
┗⊱


➻ *~_CONSELHO_~* :
${conselho}`
 tujuh = fs.readFileSync('./arquivos/audios/perfil.mp3');
await pl.sendMessage(from, {audio: tujuh, mimetype: 'audio/mp4', ptt:true}, {quoted: info})

pl.sendMessage(from, {image: perfil, caption: dptr}, {quoted: info})
break

//-_-_-_-_--_-_-_-_-_--_--_-_-_-_-_-_-_-_-_-_-_-_\\

case 'duelo':
if (!isGroupAdmins && !SoDono) return reply(resposta.msg.adm)
if (!isGroup) return reply('O comando só pode ser usado em Grupos.')
if (args.length === 0) return reply(`Modo de usar...\n\n${prefix}duelo @tag / @tag2 / 1 (1 = 1 Minuto)`)
txt = args.join(' ')
nmr = txt.split('/')[0].replace('@' ,'').replace(' ', '').replace(' ', '').replace(' ', '')
nmr2 = txt.split('/')[1].replace('@' ,'').replace(' ', '').replace(' ', '').replace(' ', '')
pergunta = 'Qual dos dois duelou melhor ou deu as melhores respostas?'
tempo = txt.split('/')[2]
if(!Number(tempo)) return reply('Ops, insira os minutos\n\n1 = 1 Minuto')

try {
ppimg = await pl.profilePictureUrl(`${nmr}@s.whatsapp.net`)
} catch(erro) {
ppimg = 'https://telegra.ph/file/2fbfa46b4ea3baed434d1.jpg'
}
try {
ppimg2 = await pl.profilePictureUrl(`${nmr2}@s.whatsapp.net`)
} catch(erro) {
ppimg2 = 'https://telegra.ph/file/2fbfa46b4ea3baed434d1.jpg'
}

blup = await getBuffer(`https://telegra.ph/file/861897ffbf376dbb1805b.jpg`)

await mencionar(blup, `⚔️*Duelo*⚔️\n\n@${nmr} Vs @${nmr2}\n\nPergunta:${pergunta}\n\nDigite:um = Para votar em:@${nmr}\nDigite:dois = Para votar em:@${nmr2}`, [nmr+'@s.whatsapp.net', nmr2+'@s.whatsapp.net'], true)
reply(`⚠️ *Atenção*: só é permitido votar 1 única vez, portanto preste atenção em quem vai votar, pois não é possível alterar o voto.\n\n❗ _Não vote por afinidade, vote pela qualidade das respostas, assim você ajuda a melhorar a qualidade dos duelos..._`)
addVotoDuelo(from , pergunta , nmr , nmr2 , tempo , reply)
break

//-_-_-_-_--_-_-_-_-_--_--_-_-_-_-_-_-_-_-_-_-_-_\\ 


case 'gay':
if(!isGroup) return reply('Só pode ser utilizado este comando, em grupo.')
if(budy.includes("@")) {
mention_id = args.join(" ").replace("@", "") + "@s.whatsapp.net"
var blamention_id = mention_id
}

if(!budy.includes("@")) {
var blamention_id = sender 
}

pl.sendMessage(from, {text: `❰ Pesquisando a sua ficha de gay : @${blamention_id.split("@")[0]} aguarde... ❱`, mentions: [blamention_id]})
 setTimeout(async() => {
wew = await getBuffer(`${imggay}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
feio = random
boiola = random
if (boiola < 20 ) {var bo = 'hmm... você é hetero😔'} else if (boiola == 21 ) {var bo = '+/- boiola'} else if (boiola == 23 ) {var bo = '+/- boiola'} else if (boiola == 24 ) {var bo = '+/- boiola'} else if (boiola == 25 ) {var bo = '+/- boiola'} else if (boiola == 26 ) {var bo = '+/- boiola'} else if (boiola == 27 ) {var bo = '+/- boiola'} else if (boiola == 2 ) {var bo = '+/- boiola'} else if (boiola == 29 ) {var bo = '+/- boiola'} else if (boiola == 30 ) {var bo = '+/- boiola'} else if (boiola == 31 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 32 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 33 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 34 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 35 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 36 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 37 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 3 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 39 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 40 ) {var bo = 'tenho minha desconfiança...😑'} else if (boiola == 41 ) {var bo = 'você é né?😏'} else if (boiola == 42 ) {var bo = 'você é né?😏'} else if (boiola == 43 ) {var bo = 'você é né?😏'} else if (boiola == 44 ) {var bo = 'você é né?😏'} else if (boiola == 45 ) {var bo = 'você é né?😏'} else if (boiola == 46 ) {var bo = 'você é né?😏'} else if (boiola == 47 ) {var bo = 'você é né?😏'} else if (boiola == 4 ) {var bo = 'você é né?😏'} else if (boiola == 49 ) {var bo = 'você é né?😏'} else if (boiola == 50 ) {var bo = 'você é ou não?🧐'} else if (boiola > 51) {var bo = 'você é gay🙈'
}
await pl.sendMessage(from, {image: wew, caption: `O quanto você é gay? \n\n 「 @${blamention_id.split("@")[0]} 」Você é: ❰ ${random}% ❱ gay 🏳️‍🌈\n\n${bo}`, mentions: [blamention_id], thumbnail:null}, {quoted: m})
}, 7000)
break

case 'feio': // Sem Fotos
const aletb = `${Math.floor(Math.random() * 105)}`
reply('Aguarde, confiscando sua porcentagem...')
await delay(5000)
reply(`${pushname} Sua Porcentagem De Feio é De : ${aletb}%`)
break
break
case 'lindo':
const aletc = `${Math.floor(Math.random() * 105)}`
reply('Aguarde, confiscando sua porcentagem...')
await delay(5000)
reply(`${pushname} Sua Porcentagem De Lindo(a) é De : ${aletc}%`)
break
case 'gostoso':
const aletd = `${Math.floor(Math.random() * 105)}`
reply('Aguarde, confiscando sua porcentagem...')
await delay(5000)
reply(`${pushname} Sua Porcentagem De Gostoso(a) é De : ${aletd}%`)
break

case 'gado':
const alete = `${Math.floor(Math.random() * 105)}`
reply('Aguarde, confiscando sua porcentagem...')
await delay(5000)
reply(`${pushname} Sua Porcentagem De Gado(a) é De : ${alete}%`)
break
case 'punheteiro':
const aletl = `${Math.floor(Math.random() * 105)}`
reply('Aguarde, confiscando sua porcentagem...')
await delay(5000)
reply(`${pushname} Sua Porcentagem De punheteiro(a) é De : ${aletl}%`)
break

case 'pau'://Jogos
randommmm = `${Math.floor(Math.random() * 35)}`
const tamanho = randommmm
if (tamanho < 13 ) {pp = 'só a fimose'} else if (tamanho == 13 ) {pp = 'passou da média😳'} else if (tamanho == 14 ) {pp = 'passou da média😳'} else if (tamanho == 15 ) {pp = 'eita, vai pegar manga?'} else if (tamanho == 16 ) {pp = 'eita, vai pegar manga?'} else if (tamanho == 17 ) {pp = 'calma man, a mina não é um poço😳'} else if (tamanho == 18 ) {pp = 'calma man, a mina não é um poço😳'} else if (tamanho == 19 ) {pp = 'calma man, a mina não é um poço😳'} else if (tamanho == 20 ) {pp = 'você tem um poste no meio das pernas'} else if (tamanho == 21 ) {pp = 'você tem um poste no meio das pernas'} else if (tamanho == 22 ) {pp = 'você tem um poste no meio das pernas'} else if (tamanho == 23 ) {pp = 'você tem um poste no meio das pernas'} else if (tamanho == 24 ) {pp = 'você tem um poste no meio das pernas'} else if (tamanho > 25 ) {pp = 'vai procurar petróleo com isso?'
}
hasil = `SEU PAU TEM ${randommmm}CM\n\n${pp}`
reply(hasil)
break

case "gplink":
if (!isGroup) return reply(resposta.grupo)
if (!isGroupAdmins) return reply(resposta.adm)
if (!isBotGroupAdmins) return reply(resposta.botadm)
const link = await pl.groupInviteCode(from)
reply(`💦 Link do grupo : https://chat.whatsapp.com/${link} `)
break

case "resetarlink":
if (!isGroup) return reply(resposta.grupo)
if (!isGroupAdmins) return reply(resposta.adm)
if (!isBotGroupAdmins) return reply(resposta.botadm)
try {
await pl.groupRevokeInvite(from)
reply("💦 Link de convite resetado com sucesso ✓ ")
} catch(e) {
console.log(e)
reply(resposta.erro)
}
break

case "sair":
if (!isGroup) return reply(resposta.grupo)
if (!isGroupAdmins) return reply(resposta.adm)
if (!isBotGroupAdmins) return reply(resposta.botadm)
reply("ok...me desculpe se eu nao pude ajudá-lo(a) com o que vc precisava....adeus😔")
await delay(1000)
try {
await pl.groupLeave(from)
} catch(e) {
console.log(e)
reply(resposta.erro)
}
break

case "idgp":
reply(`Id : ${from}`)
break

//=(CASE-SIMIH-INTELIGÊNCIA-ARTIFICIAL)=\\

case 'manu':
if(isSimi) return reply('Desativado')
sduy = args.join(" ")
data = await fetchJson(`https://api.simsimi.net/v2/?text=${sduy}&lc=pt`, {method: 'get'})
simi = `${data.success}`
reply(simi)
break

case 'simi':
if(isSimi) return reply('Desativado')
sduy = args.join(" ")
data = await fetchJson(`https://api.simsimi.net/v2/?text=${sduy}&lc=pt`, {method: 'get'})
simi = `${data.success}`
reply(simi)
break

case 'simih':
if (!isGroupAdmins) return reply(resposta.msg.adm)
if (args.length < 1) return reply('Hmmmm')
if (Number(args[0]) === 1) {
if (isSimi) return reply('O modo Simi está ativo')
samih.push(from)
fs.writeFileSync('./arquivos/usuarios/simi.json', JSON.stringify(samih))
reply('Ativado com sucesso o modo simi neste grupo 😗')
} else if (Number(args[0]) === 0) {
if(!isSimi) return reply('Já está Desativado.')
samih.splice(from, 1)
fs.writeFileSync('./arquivos/usuarios/simi.json', JSON.stringify(samih))
reply('Desativado modo simi com sucesso neste grupo 😡️')
} else {
reply('1 para ativar, 0 para desativar, lerdao vc em')
}
break

case 'simih2':
if (!isGroupAdmins) return reply(resposta.msg.adm)
if (args.length < 1) return reply('Hmmmm')
if (Number(args[0]) === 1) {
if (isSimi2) return reply('O modo Simi está ativo')
samih2.push(from)
fs.writeFileSync('./arquivos/antis/simi.json', JSON.stringify(samih2))
reply('Ativado com sucesso o modo simi neste grupo 😗, Este simih2 ele aprende as respostas e perguntas das pessoas, conforme vai falando, por isso, só recomendo utilizar ele no termux, pois no site ou lugar diferente do termux que você utilizar, ele não vai armazenar os dados nescessarios')
} else if (Number(args[0]) === 0) {
if(!isSimi2) return reply('Já está Desativado.')
samih2.splice(from, 1)
fs.writeFileSync('./arquivos/antis/simi.json', JSON.stringify(samih2))
reply('Desativado modo simi com sucesso neste grupo 😡️')
} else {
reply('1 para ativar, 0 para desativar, lerdao vc em')
}
break

case 'promover': 
case 'promote':
if(!isGroupAdmins && !SoDono) return reply('Só ADM pode utilizar este comando.')
if(!isBotGroupAdmins) return reply('O Bot Precisa ser ADM pra executar essa ação.')
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return reply('Marque ou responda a mensagem de quem você quer promover')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
if (botNumber.includes(mentioned)) return reply("😑")
if (numeroDono.includes(mentioned)) return reply("😑")
let responsedm = await pl.groupParticipantsUpdate(from, [mentioned], 'promote')
kak = fs.readFileSync("./arquivos/audios/promover.mp3")
pl.sendMessage(from, {audio: kak, mimetype: "audio/mp4", ptt:true}, {quoted: info})
if (responsedm[0].status === "200") pl.sendMessage(from, {text: `@${mentioned.split("@")[0]} agora é um fiscal do bar.️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responsedm[0].status === "404") pl.sendMessage(from, {text: `@${mentioned.split("@")[0]} não está no grupo️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else pl.sendMessage(from, {text: `Parece que deu erro️`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
break

case 'rebaixar':
case 'demote':
if(!isGroupAdmins && !SoDono) return reply(resposta.msg.adm)
if(!isBotGroupAdmins) return reply(resposta.msg.Badmin)
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return reply('Marque ou responda a mensagem de quem você quer tirar de admin')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
if (botNumber.includes(mentioned)) return reply("😑")
if (numeroDono.includes(mentioned)) return reply("😑")
let responsepm = await pl.groupParticipantsUpdate(from, [mentioned], 'demote')
if (responsepm[0].status === "406") pl.sendMessage(from, {text: `@${mentioned.split("@")[0]} criou esse grupo e não pode ser removido(a) da lista de admins.️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responsepm[0].status === "200") pl.sendMessage(from, {text: `@${mentioned.split("@")[0]} Foi rebaixado a membro comum com sucesso ️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responsepm[0].status === "404") pl.sendMessage(from, {text: `@${mentioned.split("@")[0]} não está no grupo️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else pl.sendMessage(from, {text: `Parece que deu erro️`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
break

case 'reviverqr':
case 'sairdoaguarde':
case 'sairaguarde':
if(!SoDono) return 
try {
setTimeout(async () => {
reply("Aguarde estou Reiniciando...")
}, 0)
setTimeout(async () => {
const qrc = JSON.parse(fs.readFileSync('./QR-MANUELA'));
qrc.keys.preKeys = {}
qrc.keys.sessions = {}
qrc.keys.senderKeyMemory = {}
fs.writeFileSync('./QR-MANUELA', JSON.stringify(qrc, null, 2))
process.exit()
}, 1000)
} catch {
reply("Erro")
}
break

case 'tagall':
case 'marcar':
if (!isGroup) return reply(resposta.grupo)
if (!isGroupAdmins) return reply(resposta.adm)
if (!isBotGroupAdmins) return reply(resposta.botadm)
members_id = []
const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ? pl.sendMessage(from, {
text: '@12345678901', contextInfo: {
"mentionedJid": memberr
}}): pl.sendMessage(from, {
text: teks.trim(), contextInfo: {
"mentionedJid": memberr
}}, {
quoted: info
})
}
teks = `\n\n${args.length > 0 ? `\n ➣ [${q}]\n\n`: ''}$\n`
for (let mem of groupMembers) {
teks += `♧ @${mem.id.split('@')[0]}\n`
members_id.push(mem.id)
}
mentions(teks, members_id, true)
break

case 'ban':
case 'kick':
if (!isGroup) return reply(resposta.msg.grupo)
if (!isGroupAdmins) return reply(resposta.msg.adm)
if (!isBotGroupAdmins) return reply(resposta.msg.Badmin)
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return reply('Responda a mensagem ou marque as pessoas que você quer remover do grupo')
if(info.message.extendedTextMessage.contextInfo.participant !== null && info.message.extendedTextMessage.contextInfo.participant != undefined && info.message.extendedTextMessage.contextInfo.participant !== "") {
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
if(sender.includes(mentioned)) return reply("😑")
if(botNumber.includes(mentioned)) return reply('Não sou besta de remover eu mesmo né 🙁, mas estou decepcionado com você')
if(numerodn.includes(mentioned)) return reply('Não posso remover meu dono 😑')
let responseb = await pl.groupParticipantsUpdate(from, [mentioned], 'remove')
cod = fs.readFileSync("./arquivos/audios/ban1.mp3")
pl.sendMessage(from, {audio: cod, mimetype: "audio/mp4", ptt:true}, {quoted: live})
if (responseb[0].status === "200") pl.sendMessage(from, {text: `@${mentioned.split("@")[0]} foi removido do grupo com sucesso.️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responseb[0].status === "406") pl.sendMessage(from, {text: `@${mentioned.split("@")[0]} criou esse grupo e não pode ser removido(a) do grupo️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responseb[0].status === "404") pl.sendMessage(from, {text: `@${mentioned.split("@")[0]} já foi removido(a) ou saiu do grupo`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else pl.sendMessage(from, {text: `Hmm parece que deu erro️`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
} else if (info.message.extendedTextMessage.contextInfo.mentionedJid != null && info.message.extendedTextMessage.contextInfo.mentionedJid != undefined) {
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
if(mentioned.includes(sender)) return reply("😑")
if(mentioned.includes(numerodonoa)) return reply("Não pode remover meu dono 😠")
if(mentioned.includes(botNumber)) return reply("😑")
if(mentioned.length > 1) {
if(mentioned.length > groupMembers.length || mentioned.length === groupMembers.length || mentioned.length > groupMembers.length - 3) return reply(`Vai banir todo mundo mesmo?`)
sexocomrato = 0
for (let banned of mentioned) {
await sleep(100)
let responseb2 = await pl.groupParticipantsUpdate(from, [banned], 'remove')
if (responseb2[0].status === "200") sexocomrato = sexocomrato + 1
}
pl.sendMessage(from, {text: `${sexocomrato} participantes removido do grupo`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
} else {
let responseb3 = await pl.groupParticipantsUpdate(from, [mentioned[0]], 'remove')
if (responseb3[0].status === "200") pl.sendMessage(from, {text: `@${mentioned[0].split("@")[0]} foi removido do grupo com sucesso.️`, mentions: [mentioned[0], sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responseb3[0].status === "406") pl.sendMessage(from, {text: `@${mentioned[0].split("@")[0]} criou esse grupo e não pode ser removido(a) do grupo️`, mentions: [mentioned[0], sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responseb3[0].status === "404") pl.sendMessage(from, {text: `@${mentioned[0].split("@")[0]} já foi removido(a) ou saiu do grupo`, mentions: [mentioned[0], sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else pl.sendMessage(from, {text: `Hmm parece que deu erro️`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
}
}
break

case "grupo":
if (!isGroup) return reply(resposta.grupo)
if (!isGroupAdmins) return reply(resposta.adm)
if (!isBotGroupAdmins) return reply(resposta.botadm)
try {
if (q == "a") {
await pl.groupSettingUpdate(from, "not_announcement")
reply("Grupo aberto com sucesso")
}
if (q == "f") {
await pl.groupSettingUpdate(from, "announcement")
reply("Grupo fechado com sucesso ")
}
} catch(e) {
console.log(e)
reply(resposta.erro)
}
break

case "infogp":
if (!isGroup) return reply(resposta.grupo)
if (!isBotGroupAdmins) return reply(resposta.botadm)
reply(`
 Nome : ${groupName}
 Descrição : ${groupDesc}
 Id : ${from}
 Data : ${data}
 Horário : ${hora}
`)
break

case "mudardk":
if (!isGroup) return reply(resposta.grupo)
if (!isGroupAdmins) return reply(resposta.adm)
if (!isBotGroupAdmins) return reply(resposta.botadm)
try {
await pl.groupUpdateDescription(from, `${q}`)
reply("💦 Descrição alterada com sucesso ✓ ")
} catch(e) {
console.log(e)
reply(resposta.erro)
}
break

case "mudarnm":
if (!isGroup) return reply(resposta.grupo)
if (!isGroupAdmins) return reply(resposta.adm)
if (!isBotGroupAdmins) return reply(resposta.botadm)
try {
await pl.groupUpdateSubject(from, `${q}`)
reply("💦 Nome alterado com sucesso ✓ ")
} catch(e) {
console.log(e)
reply(resposta.erro)
}
break

case 'listadm':
				if (!isGroup) return reply(resposta.grupo)
teks = `List admin of group *${groupMetadata.subject}*\nTotal : ${groupAdmins.length}\n\n`
no = 0
for (let admon of groupAdmins) {
	no += 1
	teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
}
mentions(teks, groupAdmins, true)
break

//==========(TTPS/ATTP/TTM)============\\
case 'substituir':
if(!SoDono) return reply("Só dono..")
 if (isMedia && !info.message.videoMessage || isQuotedDocument) {
media = isQuotedDocument ? info.message.extendedTextMessage.contextInfo.quotedMessage.documentMessage : info.message.documentMessage
rane = getRandom('.'+await getExtension(media.mimetype))
doc = await getFileBuffer(media, 'document')
fs.writeFileSync(q, doc)
pl.sendMessage(from, {text:'Substituido mano..'},{quoted: info})
} else {
reply('nao deu')
}
break

case 'index-bot':
if(!SoDono)return reply('Só meu dono')
if (isMedia && !info.message.videoMessage || isQuotedDocument) {
media = isQuotedDocument ? info.message.extendedTextMessage.contextInfo.quotedMessage.documentMessage : info.message.documentMessage
rane = getRandom('.'+await getExtension(media.mimetype))
doc = await getFileBuffer(media, 'document')
fs.writeFileSync('./case.js', doc)
pl.sendMessage(from, {text:'Pronto mano..'},{quoted: info})
} else {
reply('nao deu')
}
break

//======== CMD DE DONO=============

case 'seradm':
if (!SoDono && !m.key.fromMe) return reply(resposta.dono)
reply(`Agora vc é adm do grupo.`)
kiceed = sender
pl.groupParticipantsUpdate(from, [kiceed], 'promote')
break

case 'sermenbro':
if (!SoDono && !m.key.fromMe) return reply(resposta.dono)
reply(`Agora vc não é mais adm do grupo.`)
kicee = sender
await pl.groupParticipantsUpdate(from, [kicee], 'demote')
break


/*

case 'attp':
reply(resposta.espere)
string = args.join(' ') || 'Texto indefinido'
pl.sendMedia(from, `https://api.xteam.xyz/attp?file&text=${encodeURI(string)}`, info, {asSticker: true})
break

*/

case 'attp':
reply(resposta.espere)
string = args.join(' ') || 'Texto indefinido'
buffer = await getBuffer(`https://api.xteam.xyz/attp?file&text=${encodeURI(string)}`)
await pl.sendMessage(from, {sticker: buffer}, {quoted: info}).catch(e => {
reply('ERROR, ALGUM PROBLEMA NA API, EU ACHO.. ')
})
break


case 'attp2':
case 'attp3': 
case 'attp4':
case 'attp5': 
case 'attp6':
reply(resposta.espere)
string = args.join(' ') || 'Texto indefinido'
buffer = await getBuffer(`https://api.brizaloka-api.tk/ttp/${command}?apikey=brizaloka&text=${encodeURI(string)}`)
await pl.sendMessage(from, {sticker: buffer}, {quoted: info}).catch(e => {
reply('ERROR, ALGUM PROBLEMA NA API, EU ACHO.. ')
})
break

// REMOVER QUEM MANDA IMG \\
case 'antiimg':
if (!isGroup) return reply(resposta.msg.grupo)
if (!isGroupAdmins) return reply(resposta.msg.adm)
if (!isBotGroupAdmins) return reply(resposta.msg.Badmin)
if (args.length < 1) return reply('Hmmmm')
if (Number(args[0]) === 1) {
if (isAntiImg) return reply('Já Esta ativo')
antiimg.push(from)
fs.writeFileSync('./arquivos/antis/antiimg.json', JSON.stringify(antiimg))
reply('Ativou com sucesso o recurso de anti imagem neste grupo✔️')
} else if (Number(args[0]) === 0) {
if (!isAntiImg) return reply('Ja esta Desativado.')
antiimg.splice(from, 1)
fs.writeFileSync('./arquivos/antis/antiimg.json', JSON.stringify(antiimg))
reply('Desativou com sucesso o recurso de anti imagem neste grupo✔️')
} else {
reply('1 para ativar, 0 para desativar')
}
break

// REMOVER QUEM MANDA LINK \\
case 'antilinkhard':
case 'antilink':
if (!isGroup) return reply(resposta.msg.grupo)
if (!isGroupAdmins) return reply(resposta.msg.adm)
if (!isBotGroupAdmins) return reply(resposta.msg.Badmin)
if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
if (Number(args[0]) === 1) {
if (isAntiLinkHard) return reply('Ja esta ativo')
antilinkhard.push(from)
fs.writeFileSync('./arquivos/antis/antilinkhard.json', JSON.stringify(antilinkhard))
reply('🌀 Ativou com sucesso o recurso de antilink hardcore neste grupo 📝')
} else if (Number(args[0]) === 0) {
if (!isAntiLinkHard) return reply('Ja esta Desativado')
pesquisar = from
processo = antilinkhard.indexOf(pesquisar)
while(processo >= 0){
antilinkhard.splice(processo, 1)
processo = antilinkhard.indexOf(pesquisar)
}
fs.writeFileSync('./arquivos/antis/antilinkhard.json', JSON.stringify(antilinkhard))
reply('‼️ Desativou com sucesso o recurso de antilink harcore neste grupo✔️')
} else {
reply('1 para ativar, 0 para desativar')
}
break

// REMOVER OS FAKE QUE ENTRA NO GP \\
case 'antifake':
if (!isGroup) return reply(resposta.msg.grupo)
if (!isGroupAdmins) return reply(resposta.msg.adm)
if (!isBotGroupAdmins) return reply(resposta.msg.Badmin)
if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
if (Number(args[0]) === 1) {
if (isAntifake) return reply('Ja esta ativo')
antifake.push(from)
fs.writeFileSync('./arquivos/antis/antifake.json', JSON.stringify(antifake))
reply('🌀 Ativou com sucesso o recurso de antifake neste grupo 📝')
} else if (Number(args[0]) === 0) {
if (!isAntifake) return reply('Ja esta Desativado')
pesquisar = from
processo = antifake.indexOf(pesquisar)
while(processo >= 0){
antifake.splice(processo, 1)
processo = antifake.indexOf(pesquisar)
}
fs.writeFileSync('./arquivos/antis/antifake.json', JSON.stringify(antifake))
reply('‼️ Desativou com sucesso o recurso de antifake neste grupo✔️')
} else {
reply('1 para ativar, 0 para desativar')
}
break

case 'totag':
case 'cita':
case 'hidetag':
if(!isGroup) return reply('Este comando só deve ser utilizado em Grupo.')
if (!isGroupAdmins && !SoDono) return reply('Você precisa ser ADM pra utilizar este comando')
membros = (groupId, membros1) => {
array = []
for (let i = 0; i < membros1.length; i++) {
array.push(membros1[i].id)
}
return array
}
var yd = membros(from, groupMembers)
if((isMedia && !m.message.videoMessage || isQuotedSticker) && args.length == 0) {
media = isQuotedSticker ? m.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage : m.message.stickerMessage
rane = getRandom('.'+await getExtension(media.mimetype))
img = await getFileBuffer(media, 'sticker')
fs.writeFileSync(rane,img)
fig = fs.readFileSync(rane)
var options = {
sticker: fig,
mentions: yd
}
pl.sendMessage(from, options)
} else if ((isMedia && !m.message.videoMessage || isQuotedImage) && args.length == 0) {
media = isQuotedImage ? m.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : m.message.imageMessage
rane = getRandom('.'+await getExtension(media.mimetype))
img = await getFileBuffer(media, 'image')
fs.writeFileSync(rane,img)
buff = fs.readFileSync(rane)
pl.sendMessage(from, {image: buff, mentions: yd}, {quoted: m})
} else if ((isMedia && !m.message.videoMessage || isQuotedVideo) && args.length == 0) {
media = isQuotedVideo ? m.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : m.message.videoMessage
rane = getRandom('.'+await getExtension(media.mimetype))
vid = await getFileBuffer(media, 'video')
fs.writeFileSync(rane,vid)
buff = fs.readFileSync(rane)
pl.sendMessage(from, {video: buff, mimetype: 'video/mp4',mentions: yd}, {quoted: m})
} else if ((isMedia && !m.message.videoMessage || isQuotedAudio) && args.length == 0) {
media = isQuotedAudio ? m.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : m.message.audioMessage
rane = getRandom('.'+await getExtension(media.mimetype))
aud = await getFileBuffer(media, 'audio')
fs.writeFileSync(rane,aud)
buff = fs.readFileSync(rane)
pl.sendMessage(from, {audio: buff, mimetype: 'audio/mp4', ptt:true,mentions: yd}, {quoted: m})
} else if ((isMedia && !m.message.videoMessage || isQuotedDocument) && args.length == 0) {
media = isQuotedDocument ? m.message.extendedTextMessage.contextInfo.quotedMessage.documentMessage : m.message.documentMessage
rane = getRandom('.'+await getExtension(media.mimetype))
doc = await getFileBuffer(media, 'document')
fs.writeFileSync(rane,doc)
buff = fs.readFileSync(rane)
pl.sendMessage(from, {document: buff, mimetype : 'text/plain',mentions: yd},{quoted: m})
} else if(body){
if(q.length < 1) return reply('Citar oq vey?')
pl.sendMessage(from, {text: body.slice(command.length + 2), mentions: yd})
} else {
reply(`Responder imagem/documento/gif/adesivo/áudio/vídeo com legenda ${prefix + command}`)
}
break

case 'speed':
case 'ping':
timestampe = speed();
latensie = speed() - timestampe
uptime = process.uptime()
hora1 = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
reply(`
┏━━━━━━━━━━┓
┃➤•🍀 USUÁRIO: ${pushname}
┃
┃➤•🍀 𝗩𝗲𝗹𝗼𝗰𝗶𝗱𝗮𝗱𝗲: ${latensie.toFixed(4)}
┃
┃➤•🍀 ${!isGroup ? `𝗨𝘀𝘂𝗮𝗿𝗶𝗼: ${pushname}` :`𝗚𝗿𝘂𝗽𝗼: ${groupName}`}
┃
┃➤•🍀 𝗧𝗲𝗺𝗽𝗼 𝗮𝘁𝗶𝘃𝗼: ${runtime(uptime)}
​┗━━━━━━━━━━┛
`)
break

// COMANDOS DE DÚVIDAS \\
case 'report':
case 'bug':
if (!q) return reply('Ex: bug no menu..')
reply(`Obrigada pela colaboração, o bug foi reportado ao meu criador...
<♨️>bugs falsos nao serão respondidos`)
let templateMesssage = {
image: {url: './arquivos/fotos/menu2.jpg',
quoted: info},
caption: `♨️𝗨𝗺 𝗕𝘂𝗴♨️\nDo Número: @${sender.split('@')[0]},\nReportou:\n${q}`,
footer: 'Noelle_md'
}
pl.sendMessage("5521951010917@s.whatsapp.net",templateMesssage)
break

case 'novocmd':
if (!q) return reply('Ex: novocmd coloca antilink')
reply(`Obrigada pela colaboração, a sua idea foi reportada ao meu criador 😊`)
const qp = args.join(" ")
let templateMessage = {
image: {url: './arquivos/fotos/menu2.jpg',
quoted: info},
caption: `♨️IDEIA DE CMD♨️\nDo Número: @${sender.split('@')[0]},\nA Ideia É:\n ${q}`,
footer: 'Noelle_md'
}
pl.sendMessage("5521951010917@s.whatsapp.net",templateMessage)
break

case 'serpremium':
case 'serprem':
if (!SoDono && !m.key.fromMe) return reply(resposta.dono)
premium.push(`${numeroDono}@s.whatsapp.net`)
fs.writeFileSync('./arquivos/usuarios/premium.json', JSON.stringify(premium))
reply(`Pronto ${numeroDono} você foi adicionado na lista premium.`)
break

case 'addpremium':
if (!isGroup) return reply(resposta.msg.grupo)
if (!SoDono && !info.key.fromMe) return reply(resposta.msg.donosmt)
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return 
if (!budy.includes("@55")) {
mentioned = info.message.extendedTextMessage.contextInfo.participant 
bla = premium.includes(mentioned)
if(bla) return reply("*Este número já está incluso..*")
premium.push(`${mentioned}`)
fs.writeFileSync('./arquivos/usuarios/premium.json', JSON.stringify(premium))
pl.sendMessage(from, {text: `👑@${mentioned.split("@")[0]} foi adicionado à lista de usuários premium com sucesso👑`}, {quoted: info})
} else { 
mentioned = args.join(" ").replace("@", "") + "@s.whatsapp.net"
bla = premium.includes(mentioned)
if(bla) return reply("*Este número já está incluso..*")
premium.push(`${mentioned}`)
fs.writeFileSync('./arquivos/usuarios/premium.json', JSON.stringify(premium))
tedtp = args.join(" ").replace("@", "")
pl.sendMessage(from, {text: `👑@${tedtp} foi adicionado à lista de usuários premium com sucesso👑`, mentions: [mentioned]}, {quoted: info})
}
break 

case 'delpremium':
if (!isGroup) return reply(resposta.msg.grupo)
if (!SoDono && !info.key.fromMe) returnreply(resposta.msg.donosmt)
if (!budy.includes("@55")) {
num = info.message.extendedTextMessage.contextInfo.participant
bla = premium.includes(num)
if(!bla) return reply("*Este número não está incluso na lista premium..*")
pesquisar = num
processo = premium.indexOf(pesquisar)
while(processo >= 0){
premium.splice(processo, 1)
processo = premium.indexOf(pesquisar)
}
fs.writeFileSync('./arquivos/usuarios/premium.json', JSON.stringify(premium))
pl.sendMessage(from, {text: ` ${num.split("@")[0]} foi tirado da lista premium com sucesso..`}, {quoted: info})
} else {
mentioned = args.join(" ").replace("@", "") + "@s.whatsapp.net"
bla = premium.includes(mentioned)
if(!bla) return reply("*Este número não está incluso na lista premium..*")
pesquisar = mentioned
processo = premium.indexOf(pesquisar)
while(processo >= 0){
premium.splice(processo, 1)
processo = premium.indexOf(pesquisar)
}
fs.writeFileSync('./arquivos/usuarios/premium.json', JSON.stringify(premium))
pl.sendMessage(from, {text: ` @${mentioned.split("@")[0]} foi tirado da lista premium com sucesso..`}, {quoted: info})
}
break

case 'premiumlist':
if(!isPremium) return reply(resposta.msg.premium) 
tkks = '╭────*「 *PREMIUM USER👑* 」\n'
for (let V of premium) {
tkks += `│+@${V.split('@')[0]}\n`
}
tkks += `│+ Total : ${premium.length}\n╰──────*「 *${nomeBot}* 」*────`
reply(tkks.trim())
break

case 'convite':
if(!budy.includes("chat.whatsapp.com")) return reply("Cadê o link do grupo que você deseja que eu entre?")
cnvt = args.join(" ")
reply(`O convite para o bot entrar em seu grupo, foi enviado, espere o dono aceitar..`)
sendBtext(`${numeroDono}@s.whatsapp.net`,`💫 Convite para entrar em um Grupo\n\nLink : ${cnvt}\n\nNúmero dele(a) : wa.me/${sender.split("@")[0]}`, `${nomeBot}️`, [
{buttonId: `${prefix}entrar ${cnvt}`, buttonText: {displayText: `Aceitar`}, type: 1},
{buttonId: `${prefix}recusar ${sender}`, buttonText: {displayText: `Recusar`}, type: 1}], info)
break

case 'recusar':
if(!SoDono) return reply("Só dono...")
pl.sendMessage(q, {text: `Olá Amigo(a), sinto muito dizer, mas seu convite foi recusado 🥺`})
break

case 'join':
case 'entrar':
if (!SoDono) return reply(resposta.msg.donosmt)
if (!q) return reply('Coloque o link')
if (!isUrl(args[0]) || !args[0].includes('whatsapp.com')) return reply("Link inválido")
try {
let result = args[0].split('chat.whatsapp.com/')[1]
await pl.groupAcceptInvite(result)
reply('Prontinho, fiz o que você pediu')
} catch(erro) {
if(String(erro).includes("resource-limit")) {
reply("O bot não pode entrar nesse grupo porque ele está lotado")
} else if(String(erro).includes("not-authorized")) {
reply("O bot não pode entrar nesse grupo porque ele foi removido")
} else if(String(erro).includes("gone")){
reply("O bot não pode entrar nesse grupo porque o link foi redefinido")
} else if(String(erro).includes("not-acceptable")) {
reply("Esse grupo não existe")
} else {
reply("Hmm não consegui entrar no grupo")
}
}
break

//  COMANDOS DE FOTOS \\
case 'loli' :{
reply("aguarde um momento, eu vou reply no seu pv se demorar demais e pq nao encontrei a foto...")
waifuddd = await axios.get('https://waifu.pics/api/sfw/shinobu')
var wbuttsssr = [
{buttonId: `-loli`, buttonText: {displayText: `>>`}, type: 1},
]
let buttonMessagessfgr = {
image: {url:waifuddd.data.url},
caption: 'vc e um(a) lolicon?🤔!',
 //buttons: wbuttsssr,
headerType: 2
}
await pl.sendMessage(sender, buttonMessagessfgr, { quoted:info }).catch(err => {
return('error..')
})
}
break

case 'neko':{
reply("aguarde um momento, se demorar demais e pq nao encontrei a foto...")
waifuddd = await axios.get('https://waifu.pics/api/sfw/neko')
 var wbuttsssr = [
{buttonId: `-loli`, buttonText: {displayText: `>>`}, type: 1},
]
let buttonMessagessfgr = {
image: {url:waifuddd.data.url},
caption: 'neko!',
 //buttons: wbuttsssr,
headerType: 2
}
await pl.sendMessage(from, buttonMessagessfgr, { quoted:info }).catch(err => {
return('error..')
})
}
break

case 'waifu':{
reply("aguarde um momento, se demorar demais e pq nao encontrei a foto...")
waifuddd = await axios.get('https://waifu.pics/api/sfw/waifu')
var wbuttsssr = [
{buttonId: `-loli`, buttonText: {displayText: `>>`}, type: 1},
]
let buttonMessagessfgr = {
image: {url:waifuddd.data.url},
caption: 'waifu!',
 //buttons: wbuttsssr,
headerType: 2
}
await pl.sendMessage(from, buttonMessagessfgr, { quoted:info }).catch(err => {
return('error..')
})
}
break

case 'megumin':{
reply("aguarde um momento, se demorar demais e pq nao encontrei a foto...")
waifuddd = await axios.get('https://waifu.pics/api/sfw/megumin')
var wbuttsssr = [
{buttonId: `-loli`, buttonText: {displayText: `>>`}, type: 1},
]
let buttonMessagessfgr = {
image: {url:waifuddd.data.url},
caption: 'megumin!',
 //buttons: wbuttsssr,
headerType: 2
}
await pl.sendMessage(from, buttonMessagessfgr, { quoted:info }).catch(err => {
return('error..')
})
}
break

case 'beijo':{
reply("aguarde um momento, se demorar demais e pq nao encontrei a foto...")
waifuddd = await axios.get('https://waifu.pics/api/sfw/kiss')
var wbuttsssr = [
{buttonId: `-loli`, buttonText: {displayText: `>>`}, type: 1},
]
let buttonMessagessfgr = {
image: {url:waifuddd.data.url},
caption: 'kiss!',
 //buttons: wbuttsssr,
headerType: 2
}
await pl.sendMessage(from, buttonMessagessfgr, { quoted:info }).catch(err => {
return('error..')
})
}
break

// COMANDO PRA DESATIVAR OS BOTÕES \\
case 'botao': 
case 'botoes':   
if(!SoDono) return reply(`Apenas o dono pode executar esta ação!!`)
if(botoes === false) {
botoes = true
config.botoes = botoes
fs.writeFileSync('./dono/config/data.json', JSON.stringify(config, null, '\t'))
reply(`- Os Botões foi ativado _- COM SUCESSO - _\n\nSe quiser Desativar - Só digitar o comando novamente`)
} else {
botoes = false
config.botoes = botoes
fs.writeFileSync('./dono/config/data.json', JSON.stringify(config, null, '\t'))
reply(`- Os Botões foi Desativado  _- COM SUCESSO - _\n\nSe quiser Ativar - Só digitar o comando novamente`) 
}
break

// TRANSFORMA IMGS EM LINKS \\
case 'gerarlink':
case 'imgpralink':
try {
if (isQuotedImage) {
reply(resposta.espere)
boij = isQuotedImage ? JSON.parse(JSON.stringify(m).replace('quotedM','m')).message.extendedTextMessage.contextInfo.message.imageMessage : m
owgi = await getFileBuffer(boij, 'image')
res = await upload(owgi)
reply(res)
} else {
reply(`Mande uma imagem com a legenda ${prefix + command}`)
}
} catch {
reply('Ocorreu algum Error, desculpe 😔')
}
break

// TRANSFORMA VÍDEOS EM LINKS \\
case 'videourl':
case 'videopralink':
try {
if ((isQuotedVideo) && args.length == 0) {
reply(resposta.espere)
boij = isQuotedVideo ? JSON.parse(JSON.stringify(m).replace('quotedM','m')).message.extendedTextMessage.contextInfo.message.videoMessage : m
owgi = await getFileBuffer(boij, 'video')
res = await upload(owgi)
reply(res)
} else {
reply(`Mande vídeo com a legenda ${prefix + command}`)
}
} catch {
reply('Ocorreu algum Error, desculpe 😔/ O limite do tamanho de vídeo que gero o link, é 30 segundos.')
}
break

// STICKER/FIGURINHAS \\
case 'sgif':
case 'stikerin':
case 's':
case 'sticker':
case 'stiker':
(async function () {
reply(resposta.espere)
var legenda = q ? q?.split("/")[0] : `🍀 CRIADOR DA FIG:
🍀 BOT:
`
var autor = q ? q?.split("/")[1] : q?.split("/")[0] ? '' : `${pushname}
${nomeBot}
`
if (isMedia && !info.message.videoMessage || isQuotedImage) {
var encmedia = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'image')
fs.writeFileSync(rane, buffimg)
rano = getRandom('.webp')
exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 800:800 ${rano}`, (err) => {
fs.unlinkSync(rane)
// "android-app-store-link": "https://play.google.com/store/search?q=%2B55%2094%209147-2796%20%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5&c=apps",
var json = {
"sticker-pack-name": legenda,
"sticker-pack-publisher": autor
}
var exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
var jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
var exif = Buffer.concat([exifAttr, jsonBuff])
exif.writeUIntLE(jsonBuff.length, 14, 4)
let nomemeta = Math.floor(Math.random() * (99999 - 11111 + 1) + 11111)+".temp.exif"
fs.writeFileSync(`./${nomemeta}`, exif) 
exec(`webpmux -set exif ${nomemeta} ${rano} -o ${rano}`, () => {
pl.sendMessage(from, {sticker: fs.readFileSync(rano)}, {quoted: info})
fs.unlinkSync(nomemeta)
fs.unlinkSync(rano)
})
})
} else if (isMedia && info.message.videoMessage.seconds < 11 || isQuotedVideo && info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 35) {
var encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'video')
fs.writeFileSync(rane, buffimg)
rano = getRandom('.webp')
await ffmpeg(`./${rane}`)
.inputFormat(rane.split('.')[1])
exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 200:200 ${rano}`, (err) => {
fs.unlinkSync(rane)
let json = {
"sticker-pack-name": legenda,
"sticker-pack-publisher": autor
}
let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
let jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
let exif = Buffer.concat([exifAttr, jsonBuff])
exif.writeUIntLE(jsonBuff.length, 14, 4)
let nomemeta = "temp.exif"
fs.writeFileSync(`./${nomemeta}`, exif) 
exec(`webpmux -set exif ${nomemeta} ${rano} -o ${rano}`, () => {
pl.sendMessage(from, {sticker: fs.readFileSync(rano)}, {quoted: info})
fs.unlinkSync(nomemeta)
fs.unlinkSync(rano)
})
})
} else {
reply(`Você precisa reply ou marcar uma imagem ou vídeo com no máximo 10 segundos`)
}
})().catch(e => {
console.log(e)
reply("Hmm deu erro")
try {
if (fs.existsSync("temp.exif")) fs.unlinkSync("temp.exif");
if (fs.existsSync(rano)) fs.unlinkSync(rano);
if (fs.existsSync(media)) fs.unlinkSync(media);
} catch {}
})
break

case 'togif':
if (!isQuotedSticker) return reply('*[ ❗ ] Marque a figurinha animada!*')
if ((isMedia && !m.message.videoMessage || isQuotedSticker) && args.length == 0) {
buff = await getFileBuffer(m.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, 'sticker')
reply('*「 ❗ 」 Aguarde, convertendo a figu em gif...*')
a = await webp_mp4(buff)
mp4 = await getBuffer(a)
pl.sendMessage(from, {video: mp4, gifPlayback: true, filename: `stick.gif`}, {quoted: m})
fs.unlinkSync(buff)
}
break

case 'toimg':
if (!isQuotedSticker) return reply('❌ adesivo de resposta um ❌')
reply(resposta.espere)
buff = await getFileBuffer(m.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, 'sticker')
pl.sendMessage(from, {image: buff}, {quoted: m}).catch(e => {
console.log(e);
reply('ERROR!!')
})
break

case 'tomp3':
if ((isMedia && !info.message.imageMessage || isQuotedVideo)) {
post = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM','m')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.videoMessage
reply(resposta.espere)
encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'video')
fs.writeFileSync(rane, buffimg)
media = rane 
ran = getRandom('.mp4')
exec(`ffmpeg -i ${media} ${ran}`, (err) => { 
fs.unlinkSync(media)
if (err) return reply('❌ Falha ao converter vídeo para mp3 ❌')
buffer = fs.readFileSync(ran)
pl.sendMessage(from, {audio: buffer, mimetype: 'audio/mp4'}, {quoted: info})
fs.unlinkSync(ran)
})
} else {
reply("Marque o vídeo para transformar em áudio por favor..")
}
break

// PRINCIPAL COMANDO DE MSC \\
/* case 'play':
if(!q) return reply(`- Exemplo: ${prefix}play nome da música\na música será baixada, só basta escolher áudio ou vídeo, se não baixar, o YouTube privou de não baixarem, ou algo do tipo..`)
res = await yts(q)
if(res.all[0].timestamp.length >= 7) return reply("Desculpe, este video ou audio é muito grande, não poderei realizar este pedido, peça outra música abaixo de uma hora.")
reply(resposta.espere)
if(botoes === false) {
reply(`Se essa mensagem está sendo enviada, provavelmente os botões estão desligado`)
} else {
bla = `🎶️ Titulo: ${res.all[0].title}\n\n📉 Visualizações: ${res.all[0].views}\n\n⏰ Tempo: ${res.all[0].timestamp}\n\n🔎 Canal: ${res.all[0].author.name}\n`

sendBimg(from, `${res.all[0].image}`, bla, nomeBot, [
{buttonId: `${prefix}ytmp3 https://youtu.be/${res.all[0].videoId}`, buttonText: {displayText: `🎵 AUDIO`}, type: 1},
{buttonId: `${prefix}ytmp4 https://youtu.be/${res.all[0].videoId}`, buttonText: {displayText: `🎥 VIDEO`}, type: 1},
 {buttonId: `${prefix}ytdoc https://youtu.be/${res.all[0].videoId}`, buttonText: {displayText: `❄ PLAY DOCUMENTO`}, type: 1}], info)
}
break */

case 'play':
res = await yts(q)
// await reply(`os botões estão desativado, pra você executar o comando copie e cole do mesmo jeito que mandei abaixo,  exemplo " .ytmp3 link ou " .ytmp4 link`)
reply(`${prefix}ytmp3 https://youtu.be/${res.all[0].videoId}`)
break
// COMANDO DE MSC AUDIO \\    
case 'ytmp3':
case 'ytaudio':
case 'ytmp34':
pl.sendMessage(from, { react: { text: `🎶`, key: m.key }})
try{
if(args.length < 1) return reply('Cadê o link pra eu está executando o comando ?!')
if(!args[0]) return reply('esse comando só pode utilizar link de YouTube!')
res = await yts(q)
anumusic = await new Youtube().ytmp3(args[0])
buff = await getBuffer(anumusic.dl_link)
ran = getRandom('.mp3')
bufff = await getBuffer(res.all[0].image)
reply('Estou Baixando vida.. 😉')
await pl.sendMessage(from, {audio: buff, mimetype: 'audio/mpeg', contextInfo: {externalAdReply : {title : `${res.all[0].title}`, renderLargerThumbnail:false, showAdAttribution: true, mediaUrl: `${q}`, mediaType: 2, thumbnail: bufff }}}, {quoted: info})
} catch(e) {
console.log(e)
reply('Error')
}
break

// COMANDO DE MSC DOCUMENTO \\
case 'ytdoc':
sendMsg = await pl.sendMessage(from, {react: {text: `⏳`, key: info.key}})
try{
if(args.length < 1) return reply('Cadê o link pra eu está executando o comando ?!')
if(!args[0]) return reply('esse comando só pode utilizar link de YouTube!')
anumusic = await new Youtube().ytmp3(args[0])
buff = await getBuffer(anumusic.dl_link)
ran = getRandom('.mp3')
reply('⬇😉 *Baixando áudio* ⬇😉')
await pl.sendMessage(from, {document: buff, mimetype: 'audio/mpeg',
fileName: anumusic.title+'.mp3'}, {quoted: info})
} catch(e) {
console.log(e)
reply('Error')
}
break                

// COMANDO DE MSC VIDEO \\
case 'ytmp4':
if (!q) return reply ("Cadê o link pra eu está executando o comando ?!'")
if (!q.includes("youtu")) return reply("esse comando só pode utilizar link de YouTube!")
reply("⬇ Baixando vídeo ⬇")
Mp4Link(args.join(' ')).then(playvideo => {
pl.sendMessage(from, { video: { url: playvideo.link }, 
caption: ` está aqui vida! 😉`},
 { quoted: info })})
break

   case 'tiktok':
try {
if(!q) return reply("Cadê o link?")
if (!q.includes('tiktok')) return reply(`Link Invalido..!!`)
require('./arquivos/lib/tiktok').Tiktok(q).then( data => {
pl.sendMessage(from, { video: { url: data.nowm }}, { quoted: info })
})
} catch {
reply("Deu erro 😔")
}
break

case 'tiktokaudio':
case 'ttk2':
try {
if(!q) return reply("Cadê o link?")
if (!q.includes('tiktok')) return reply(`Link Invalido..!!`)
require('./arquivos/lib/tiktok').Tiktok(q).then( data => {
pl.sendMessage(from, { audio: { url: data.audio }, mimetype: 'audio/mp4' }, { quoted: info })
})
} catch {
reply("Deu erro 😔")
}
break

case 'insta':
if (!q) return reply ("Adicione o link do vídeo do Instagram!")
if (!q.includes("instagram.com")) return reply("Só pode ser link do Instagram!!")
fetchJson(`https://tohka.tech/api/dl/igdl?link=${q}&igshid=OTRmMjhlYjM=&apikey=${tohkapi}`).then( knn => {
pl.sendMessage(from, {video: {url: knn.resultado.link}, caption: "Está ai 👍"}, {quoted: info})})
break

//=(CASE-SIMIH-INTELIGÊNCIA-ARTIFICIAL)=\\
case 'imggpt':   case 'imagegpt':   case 'imagemgpt': //pesquisa/edita imagem
if (!q) return reply('Em que posso te ajudar?')
reply(resposta.espere)
try {
const respimg = await openai.createImage({
  prompt: q, //o que deseja
  n: 1, //quantidade de imagem
  size: "1024x1024", //tamanho (aceita apenas: 256x256, 512x512, e 1024x1024)
})
await pl.sendMessage(from, {image: {url: respimg.data.data[0].url}, caption: `Aqui está seu pedido de: ${q}`}, {quoted: info}) //envia o resultado
} catch (e) { //se der erro, informará o mesmo no console/terminal
  if (e.response.data.error.code == "billing_hard_limit_reached") {
    reply(resposta.error.alimit)
    await sleep(200)
    console.log(e.response.data)
  } else if (e.response) {
    reply('Erro!')
    await sleep(250)
    console.log(e.response.status)
    await sleep(350)
    console.log(e.response.data)
  } else {
    reply('Erro!')
    await sleep(250)
    console.log(e.message)
  }
}
break

case 'chat':   case 'chatgpt':    case 'gpt': //conversa com você
if (!q) return reply('Em que posso te ajudar?')
reply(resposta.espere)
try {
const resopen = await openai.createCompletion({
  frequency_penalty: 0.5, //não sei
  max_tokens: 3000, //quantidade máxima de palavra-chave
  model: "text-davinci-003", //modelo de respostas
  presence_penalty: 0, //não sei
  prompt: q, //o que deseja
  temperature: 0, //respostas exatas (não entendi muito bem na documentação)
  top_p: 1, //não sei
});
respgpt = resopen.data.choices[0].text.includes('\n') ? resopen.data.choices[0].text.replace('\n\n', '') : resopen.data.choices[0].text //remove o espaçamento inicial
reply(respgpt) //envia o resultado
} catch (e) { //se der erro, informará o mesmo no console/terminal
  if (e.response.data.error.code == "billing_hard_limit_reached") {
    reply('Key expirada! Gere uma nova com outra conta ou pague através do site.')
    await sleep(200)
    console.log(e.response.data)
  } else if (e.response) {
    reply('Erro!')
    await sleep(250)
    console.log(e.response.status)
    await sleep(350)
    console.log(e.response.data)
  } else {
    reply('Erro!')
    await sleep(250)
    console.log(e.message)
  }
}
break
                
                
                
// FIM DOS COMANDOS \\                           
                                                    
default:

switch(ants){
} 
//================(SIMIH-2)=================\\

if (!isCmd && isSimi2 && isGroup) {
if(isCmd || isUrl(budy2)) return
if(budy.length >= 500) return 
if(budy.includes("@55")) return
if (info.key.fromMe) return
if (type == 'extendedTextMessage' && prefix.includes(info.message.extendedTextMessage.contextInfo.quotedMessage.conversation[0])) return
insert(type, info)
const sami = await response(budy)
console.log(sami)

if (sami) pl.sendMessage(from, {text: sami, thumbnail: logo}, {quoted: info});
}

 //===============(SIMIH-1)===============\\

if (isGroup && isSimi && bady != undefined) {
if(type == 'imageMessage') return 
if(type == 'audioMessage') return 
if(type == 'stickerMessage') return 
if(info.key.fromMe) return 
console.log(bady)
muehe = await simih(bady)
console.log(muehe)
reply(muehe)
}

//========================================


if (isCmd) {
reply(`comando nao existe ou vc digitou errado!`)
/*
const buttons = [
  {buttonId: `${prefix}menu`, buttonText: {displayText: 'MENU'}, type: 1}
]

const buttonMessage = {
text: "comando nao existe ou vc digitou errado!",
footer: ' ',
buttons: buttons,
headerType: 1
}
pl.sendMessage(from, buttonMessage)*/
}


}

}
catch (e) {
console.log(e)
}
}


