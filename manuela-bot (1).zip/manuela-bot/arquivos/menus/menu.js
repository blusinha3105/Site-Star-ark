const menu = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return `
╔═══════════╗
┣⋆⃟ۣۜ᭪Usuário: ${pushname} 
┣⋆⃟ۣۜ᭪Dono: ${nomeDono}
┣⋆⃟ۣۜ᭪Bot: ${nomeBot}
▬▭▬▭▬▭▬▭▬▭
╔═══════════
║menufotos
║═══════════
║menuadm
║═══════════
║menubrincadeira
║═══════════
║menualeatorio
║═══════════
║menufotos
║═══════════
║menufig
╚═══════════╝
`
}
exports.menu = menu

const menufig = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return `
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}s
┣⋆⃟ۣۜ᭪➣${prefix}attp
┣⋆⃟ۣۜ᭪➣${prefix}attp2
┣⋆⃟ۣۜ᭪➣${prefix}attp3
┣⋆⃟ۣۜ᭪➣${prefix}attp4
┣⋆⃟ۣۜ᭪➣${prefix}attp5
┣⋆⃟ۣۜ᭪➣${prefix}attp6
┣⋆⃟ۣۜ᭪➣${prefix}toimg
┣⋆⃟ۣۜ᭪➣${prefix}togif
╚═══════════╝
`
}
exports.menufig = menufig


const menuadm = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return `
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}antilink 1 / 0
┣⋆⃟ۣۜ᭪➣${prefix}antifake 1 / 0
┣⋆⃟ۣۜ᭪➣${prefix}antiimg 1 / 0
┣⋆⃟ۣۜ᭪➣${prefix}antilinkhard 1 / 0
┣⋆⃟ۣۜ᭪➣${prefix}resetarlink
┣⋆⃟ۣۜ᭪➣${prefix}botsai
┣⋆⃟ۣۜ᭪➣${prefix}hidetag
┣⋆⃟ۣۜ᭪➣${prefix}ban 
┣⋆⃟ۣۜ᭪➣${prefix}mudardk
┣⋆⃟ۣۜ᭪➣${prefix}mudarnm
┣⋆⃟ۣۜ᭪➣${prefix}grupo a
┣⋆⃟ۣۜ᭪➣${prefix}grupo f
┣⋆⃟ۣۜ᭪➣${prefix}promover @
┣⋆⃟ۣۜ᭪➣${prefix}rebaixar @
┣⋆⃟ۣۜ᭪➣${prefix}duelo @ / @ /2
┣⋆⃟ۣۜ᭪➣${prefix}hidetag 
┣⋆⃟ۣۜ᭪➣${prefix}totag
╚═══════════╝
`
}
exports.menuadm = menuadm

const menubrincadeira = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return `
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}cassino 
┣⋆⃟ۣۜ᭪➣${prefix}ppt
┣⋆⃟ۣۜ᭪➣${prefix}gay
┣⋆⃟ۣۜ᭪➣${prefix}gado
┣⋆⃟ۣۜ᭪➣${prefix}gostoso
┣⋆⃟ۣۜ᭪➣${prefix}punheteiro
┣⋆⃟ۣۜ᭪➣${prefix}lindo
┣⋆⃟ۣۜ᭪➣${prefix}feio
┣⋆⃟ۣۜ᭪➣${prefix}pau
┣⋆⃟ۣۜ᭪➣${prefix}simih
┣⋆⃟ۣۜ᭪➣${prefix}simih2
┣⋆⃟ۣۜ᭪➣${prefix}simi
┣⋆⃟ۣۜ᭪➣${prefix}manu
╚═══════════╝

`
}
exports.menubrincadeira = menubrincadeira

const menualeatorio = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return ` 
     -menu-
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}menuprem
┣⋆⃟ۣۜ᭪➣${prefix}menuadm
┣⋆⃟ۣۜ᭪➣${prefix}video
┣⋆⃟ۣۜ᭪➣${prefix}audio
┣⋆⃟ۣۜ᭪➣${prefix}perfil
┣⋆⃟ۣۜ᭪➣${prefix}listadm
┣⋆⃟ۣۜ᭪➣${prefix}ping
┣⋆⃟ۣۜ᭪➣${prefix}infogp
┣⋆⃟ۣۜ᭪➣${prefix}gerarlink
┣⋆⃟ۣۜ᭪➣${prefix}videopralink
┣⋆⃟ۣۜ᭪➣${prefix}play
┣⋆⃟ۣۜ᭪➣${prefix}tiktok
┣⋆⃟ۣۜ᭪➣${prefix}tiktokaudio
┣⋆⃟ۣۜ᭪➣${prefix}insta
┣⋆⃟ۣۜ᭪➣${prefix}convite
┣⋆⃟ۣۜ᭪➣${prefix}tomp3
╚═══════════╝
    *♨️⭐️♨️*
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}novocmd
┣⋆⃟ۣۜ᭪➣${prefix}bug
╚═══════════╝
    *sticker*
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}s
┣⋆⃟ۣۜ᭪➣${prefix}toimg
╚═══════════╝
*Dono*
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}reiniciar
┣⋆⃟ۣۜ᭪➣${prefix}tmgp
┣⋆⃟ۣۜ᭪➣${prefix}botoes
┣⋆⃟ۣۜ᭪➣${prefix}addpremium
┣⋆⃟ۣۜ᭪➣${prefix}delpremium 
┣⋆⃟ۣۜ᭪➣${prefix}serpremium 
┣⋆⃟ۣۜ᭪➣${prefix}substituir
┣⋆⃟ۣۜ᭪➣${prefix}index-bot
┣⋆⃟ۣۜ᭪➣${prefix}reniciarqr
┣⋆⃟ۣۜ᭪➣${prefix}seradm
┣⋆⃟ۣۜ᭪➣${prefix}sermenbro
╚═══════════╝
`
}
exports.menualeatorio = menualeatorio

const menufotos = (prefix, nomeBot, numeroDono, nomeDono, hora, data, pushname, sender) => {
return `
╔═══════════╗
┣⋆⃟ۣۜ᭪➣${prefix}neko
┣⋆⃟ۣۜ᭪➣${prefix}loli
┣⋆⃟ۣۜ᭪➣${prefix}waifu
┣⋆⃟ۣۜ᭪➣${prefix}megumin
┣⋆⃟ۣۜ᭪➣${prefix}beijo
╚═══════════╝


`
}
exports.menufotos = menufotos

